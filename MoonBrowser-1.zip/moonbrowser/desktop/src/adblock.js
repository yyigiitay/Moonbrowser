'use strict';
// Reklam & izleyici engelleme listesi (alan adı + tüm alt alan adları engellenir)
const AD_HOSTS = new Set([
  'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'google-analytics.com', 'googletagmanager.com',
  'googletagservices.com', 'adservice.google.com', 'adservice.google.com.tr', 'pagead2.googlesyndication.com', 'imasdk.googleapis.com',
  'connect.facebook.net', 'pixel.facebook.com', 'an.facebook.com', 'ads.twitter.com', 'analytics.twitter.com', 'ads.linkedin.com',
  'px.ads.linkedin.com', 'analytics.tiktok.com', 'ads.tiktok.com', 'amazon-adsystem.com', 'adnxs.com', 'adsrvr.org', 'criteo.com',
  'criteo.net', 'taboola.com', 'outbrain.com', 'outbrainimg.com', 'pubmatic.com', 'rubiconproject.com', 'openx.net', 'casalemedia.com',
  'moatads.com', 'quantserve.com', 'scorecardresearch.com', 'hotjar.com', 'hotjar.io', 'mouseflow.com', 'fullstory.com', 'crazyegg.com',
  'mc.yandex.ru', 'mc.yandex.com', 'an.yandex.ru', 'yandexadexchange.net', 'ads.yahoo.com', 'advertising.com', 'adform.net',
  'smartadserver.com', 'teads.tv', 'sharethrough.com', 'media.net', 'zemanta.com', 'mgid.com', 'revcontent.com', 'propellerads.com',
  'popads.net', 'popcash.net', 'exoclick.com', 'adsterra.com', 'onclickads.net', 'trafficjunky.net', 'juicyads.com', 'admatic.com.tr',
  'admaticsupply.com', 'reklamstore.com', 'reklamaction.com', 'adhood.com', 'segmentify.com', 'insider.com.tr', 'useinsider.com',
  'clarity.ms', 'bat.bing.com', 'branch.io', 'app-measurement.com', 'appsflyer.com', 'adjust.com', 'mixpanel.com', 'segment.io',
  'segment.com', 'amplitude.com', 'newrelic.com', 'nr-data.net', 'bugsnag.com', 'chartbeat.com', 'chartbeat.net', 'parsely.com',
  'demdex.net', 'omtrdc.net', '2o7.net', 'everesttech.net', 'bluekai.com', 'krxd.net', 'adsafeprotected.com', 'doubleverify.com',
  'serving-sys.com', 'flashtalking.com', 'yieldmo.com', 'gumgum.com', 'sonobi.com', 'lijit.com', 'sovrn.com', 'contextweb.com',
  'indexww.com', '33across.com', 'bidswitch.net', 'smaato.net', 'inmobi.com', 'unityads.unity3d.com', 'coinhive.com', 'coin-hive.com',
  'cryptoloot.pro', 'webminepool.com'
]);

function isAdHost(host) {
  host = (host || '').toLowerCase();
  while (host.includes('.')) {
    if (AD_HOSTS.has(host)) return true;
    host = host.slice(host.indexOf('.') + 1);
  }
  return false;
}

const COSMETIC_CSS = `
ins.adsbygoogle, .adsbygoogle, [id^="google_ads_"], [id^="div-gpt-ad"], [data-ad-slot], [data-ad-unit],
iframe[src*="doubleclick.net"], iframe[src*="googlesyndication"], iframe[id^="google_ads_iframe"],
.ad-banner, .ad-container, .ad-wrapper, .ad-slot, .advert, .advertisement, .sponsored-ad, .sticky-ad,
#taboola-below-article-thumbnails, [id^="taboola-"], .trc_related_container, .OUTBRAIN, [data-widget-id^="AR_"],
#carbonads, .reklam, .reklam-alani, [class^="reklam_"], [id^="reklam"]
{ display: none !important; visibility: hidden !important; height: 0 !important; min-height: 0 !important; }
`;

module.exports = { isAdHost, COSMETIC_CSS };
