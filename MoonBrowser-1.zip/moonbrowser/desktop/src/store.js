'use strict';
const fs = require('fs');
const path = require('path');

// Basit, atomik yazan JSON deposu (çökmeye karşı .tmp + rename)
class Store {
  constructor(file, defaults) {
    this.file = file;
    this.data = structuredClone(defaults);
    try {
      const saved = JSON.parse(fs.readFileSync(file, 'utf8'));
      for (const k of Object.keys(defaults)) {
        if (saved[k] === undefined) continue;
        const d = defaults[k];
        this.data[k] = d && typeof d === 'object' && !Array.isArray(d) ? { ...d, ...saved[k] } : saved[k];
      }
    } catch { /* ilk çalıştırma */ }
  }
  get(k) { return this.data[k]; }
  set(k, v) { this.data[k] = v; this.save(); }
  save() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.flush(), 400);
  }
  flush() {
    clearTimeout(this.timer);
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.data, null, 2));
      fs.renameSync(this.file + '.tmp', this.file);
    } catch (e) { console.error('Kayıt hatası:', e); }
  }
}

module.exports = Store;
