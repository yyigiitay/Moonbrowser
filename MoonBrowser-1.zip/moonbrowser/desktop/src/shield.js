'use strict';
let toUnicode = h => h;
try { toUnicode = require('url').domainToUnicode || toUnicode; } catch { /* tarayıcı ortamı */ }

// Kiril/Yunan harflerinden Latin görünümlü olanlar (homoglif)
const CONFUSABLE = { 'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x', 'і': 'i', 'ј': 'j', 'ѕ': 's', 'һ': 'h', 'ԁ': 'd', 'ɡ': 'g', 'ο': 'o', 'α': 'a', 'ν': 'v', 'τ': 't', 'κ': 'k', 'ρ': 'p', 'ι': 'i', 'ӏ': 'l', 'ԛ': 'q', 'ԝ': 'w', 'ɩ': 'l' };
/*
 * Ay Kalkanı — yerel risk analiz motoru.
 * Her adresi açılmadan önce 15+ sinyalle puanlar (0-100). Hiçbir veri dışarı gönderilmez.
 * Kural tabanlı, açıklanabilir bir modeldir: her puanın nedeni kullanıcıya gösterilir.
 */

const MULTI_SUFFIX = new Set([
  'com.tr', 'gov.tr', 'org.tr', 'net.tr', 'edu.tr', 'bel.tr', 'k12.tr', 'av.tr', 'gen.tr', 'biz.tr', 'info.tr', 'pol.tr', 'tsk.tr',
  'co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'com.au', 'net.au', 'co.jp', 'com.br', 'co.nz', 'co.za', 'com.cn', 'com.mx', 'co.in', 'com.de'
]);

const SUSPICIOUS_TLDS = new Set([
  'zip', 'mov', 'tk', 'ml', 'ga', 'cf', 'gq', 'xyz', 'top', 'click', 'country', 'kim', 'work', 'rest', 'fit', 'loan',
  'men', 'bid', 'win', 'review', 'date', 'racing', 'download', 'stream', 'cam', 'icu', 'monster', 'sbs', 'cfd', 'buzz', 'lol', 'quest'
]);

const BRANDS = {
  paypal: ['paypal.com'], apple: ['apple.com', 'icloud.com'], icloud: ['icloud.com', 'apple.com'],
  microsoft: ['microsoft.com', 'live.com', 'office.com', 'microsoftonline.com', 'outlook.com'], outlook: ['outlook.com', 'live.com', 'microsoft.com'],
  google: ['google.com', 'google.com.tr', 'youtube.com', 'gmail.com', 'googleusercontent.com', 'gstatic.com'], gmail: ['gmail.com', 'google.com'],
  youtube: ['youtube.com', 'youtu.be', 'google.com'], facebook: ['facebook.com', 'fb.com', 'facebook.net'], instagram: ['instagram.com'],
  whatsapp: ['whatsapp.com', 'whatsapp.net'], netflix: ['netflix.com'], amazon: ['amazon.com', 'amazon.com.tr', 'amazonaws.com'],
  garanti: ['garantibbva.com.tr', 'garanti.com.tr'], ziraat: ['ziraatbank.com.tr', 'ziraat.com.tr'], akbank: ['akbank.com', 'akbank.com.tr'],
  isbank: ['isbank.com.tr'], yapikredi: ['yapikredi.com.tr'], halkbank: ['halkbank.com.tr'], vakifbank: ['vakifbank.com.tr'],
  denizbank: ['denizbank.com'], enpara: ['enpara.com'], papara: ['papara.com'], edevlet: ['turkiye.gov.tr'], turkiye: ['turkiye.gov.tr'],
  ptt: ['ptt.gov.tr', 'pttavm.com'], hepsiburada: ['hepsiburada.com'], trendyol: ['trendyol.com'], sahibinden: ['sahibinden.com'],
  binance: ['binance.com', 'binance.tr'], metamask: ['metamask.io'], steam: ['steampowered.com', 'steamcommunity.com'],
  telegram: ['telegram.org', 't.me'], twitter: ['twitter.com', 'x.com'], linkedin: ['linkedin.com'], dropbox: ['dropbox.com']
};

const TRUSTED = new Set(Object.values(BRANDS).flat().concat([
  'wikipedia.org', 'github.com', 'stackoverflow.com', 'mozilla.org', 'duckduckgo.com', 'bing.com', 'yandex.com.tr', 'yandex.ru',
  'brave.com', 'startpage.com', 'claude.ai', 'anthropic.com', 'reddit.com', 'cloudflare.com'
]));

const SHORTENERS = new Set(['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'is.gd', 'cutt.ly', 'ow.ly', 'rebrand.ly', 'shorturl.at', 'tiny.cc', 'rb.gy']);
const FREE_HOSTS = ['000webhostapp.com', 'firebaseapp.com', 'web.app', 'glitch.me', 'netlify.app', 'vercel.app', 'pages.dev',
  'ngrok.io', 'ngrok-free.app', 'trycloudflare.com', 'weebly.com', 'wixsite.com', 'blogspot.com', 'repl.co', 'herokuapp.com'];

const HOST_WORDS = ['login', 'signin', 'verify', 'secure', 'account', 'update', 'banking', 'wallet', 'giris', 'dogrula', 'sifre', 'hesap',
  'odeme', 'kampanya', 'hediye', 'odul', 'iade', 'destek', 'support', 'confirm', 'unlock', 'billing'];
const PATH_WORDS = ['login', 'signin', 'verify', 'wp-admin', 'webscr', 'giris', 'dogrulama', 'sifre', 'odeme', 'kart', 'card', 'cvv'];

function getSite(host) {
  const labels = host.split('.');
  if (labels.length <= 2) return host;
  const last2 = labels.slice(-2).join('.');
  if (MULTI_SUFFIX.has(last2)) return labels.slice(-3).join('.');
  return last2;
}

function isIp(host) {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.startsWith('[') || /^[0-9a-f:]+$/i.test(host) && host.includes(':');
}

function deLeet(s) {
  return s.replace(/0/g, 'o').replace(/1/g, 'l').replace(/3/g, 'e').replace(/4/g, 'a').replace(/5/g, 's').replace(/7/g, 't').replace(/rn/g, 'm').replace(/vv/g, 'w');
}

function lev(a, b) {
  if (Math.abs(a.length - b.length) > 1) return 9;
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) {
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  }
  return d[a.length][b.length];
}

function analyzeUrl(urlStr) {
  let u;
  try { u = new URL(urlStr); } catch { return { score: 0, level: 'safe', reasons: [] }; }
  if (!/^https?:$/.test(u.protocol)) return { score: 0, level: 'internal', reasons: [] };

  const host = u.hostname.toLowerCase();
  const site = getSite(host);
  const reasons = [];
  let score = 0;
  const add = (pts, why) => { score += pts; reasons.push({ pts, why }); };

  if (host === 'localhost' || host.endsWith('.local') || /^(127|10)\./.test(host) || /^192\.168\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host)) {
    return { score: 0, level: 'safe', reasons: [] }; // yerel ağ (modem, NAS, geliştirme sunucusu)
  }

  const punycode = host.split('.').some(l => l.startsWith('xn--'));
  if (TRUSTED.has(site) && !punycode && !u.username) {
    if (u.protocol === 'http:') add(10, 'Şifrelenmemiş bağlantı (HTTP)');
    return finish(score, reasons);
  }

  if (u.protocol === 'http:') add(10, 'Şifrelenmemiş bağlantı (HTTP)');
  if (isIp(host)) add(30, 'Alan adı yerine çıplak IP adresi kullanılıyor');
  let uniHost = host;
  if (punycode) {
    uniHost = toUnicode(host) || host;
    const mixed = /[a-z]/.test(uniHost) && /[\u0370-\u03ff\u0400-\u04ff]/.test(uniHost);
    add(mixed ? 45 : 25, mixed ? `Karışık alfabe hilesi: "${uniHost}" Latin harf gibi görünen Kiril/Yunan harfler içeriyor`
      : 'Uluslararası karakterli alan adı (punycode)');
  }
  if (u.username || u.password) add(30, 'Adreste "@" hilesi — gerçek hedef gizleniyor');
  if (u.port && !['80', '443'].includes(u.port)) add(10, `Alışılmadık port (${u.port})`);

  const sub = host.slice(0, Math.max(0, host.length - site.length - 1));
  const subDepth = sub ? sub.split('.').length : 0;
  if (subDepth >= 3) add(15, 'Çok fazla alt alan adı katmanı');
  const hyphens = (host.replace(/xn--/g, '').match(/-/g) || []).length;
  if (hyphens >= 3) add(12, 'Alan adında aşırı tire kullanımı');

  const tld = host.split('.').pop();
  if (SUSPICIOUS_TLDS.has(tld)) add(18, `Dolandırıcılıkta sık görülen uzantı (.${tld})`);
  if (host.length > 40) add(8, 'Olağandışı uzun alan adı');
  if (urlStr.length > 220) add(5, 'Olağandışı uzun adres');
  if (SHORTENERS.has(host)) add(10, 'Kısaltılmış bağlantı — gerçek hedef gizli');
  if (FREE_HOSTS.some(h => host === h || host.endsWith('.' + h))) add(10, 'Ücretsiz barındırma servisi (oltalama sitelerinde yaygın)');

  const hostWords = HOST_WORDS.filter(w => host.includes(w));
  if (hostWords.length) add(Math.min(20, hostWords.length * 10), `Alan adında güven sömürüsü kelimeler: ${hostWords.join(', ')}`);
  const path = (u.pathname + u.search).toLowerCase();
  const pathWords = PATH_WORDS.filter(w => path.includes(w));
  if (pathWords.length) add(Math.min(10, pathWords.length * 5), 'Adres yolunda giriş/ödeme kelimeleri');

  // Marka taklidi & yazım hilesi
  const hostFlat = [...uniHost].map(c => CONFUSABLE[c] || c).join('').replace(/[.-]/g, '');
  const hostLeet = deLeet(hostFlat);
  const siteLabel = site.split('.')[0];
  for (const [brand, official] of Object.entries(BRANDS)) {
    if (official.includes(site)) continue;
    if (hostFlat.includes(brand)) { add(45, `"${brand}" markasını taklit ediyor olabilir (resmi alan adı değil)`); break; }
    if (hostLeet.includes(brand)) { add(55, `"${brand}" adının harf/rakam hilesiyle yazılmış hali`); break; }
    if (brand.length >= 5 && lev(siteLabel, brand) === 1) { add(50, `"${brand}" adına çok benzeyen yazım (typosquatting)`); break; }
  }

  return finish(score, reasons);
}

function finish(score, reasons) {
  score = Math.min(100, score);
  return { score, level: score >= 65 ? 'danger' : score >= 30 ? 'caution' : 'safe', reasons };
}

module.exports = { analyzeUrl, getSite };
