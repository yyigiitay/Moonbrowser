'use strict';
const $ = s => document.querySelector(s);
const I = window.ICONS;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const letter = t => esc((String(t || '?').replace(/^(https?:\/\/)?(www\.)?/, '')[0] || '?').toUpperCase());
const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; } };

let state = { tabs: [], activeId: null, bookmarks: [], settings: {}, stats: {} };
let section = 'shield';
let editingAddress = false;

if (moon.platform === 'darwin') document.body.classList.add('mac');

// statik ikonlar
$('#btn-newtab').innerHTML = I.plus;
$('#btn-newpriv').innerHTML = I.mask;
$('#btn-back').innerHTML = I.back;
$('#btn-fwd').innerHTML = I.fwd;
$('#btn-home').innerHTML = I.home;
$('#btn-tasks').innerHTML = I.tasks;
$('#btn-panel').innerHTML = I.panel;
$('#btn-blocked .pill-ico').innerHTML = I.block;

// ───────── olaylar ─────────
$('#btn-newtab').onclick = () => moon.send('tab:new', {});
$('#btn-newpriv').onclick = () => moon.send('tab:new', { priv: true });
$('#btn-back').onclick = () => moon.send('nav:back');
$('#btn-fwd').onclick = () => moon.send('nav:forward');
$('#btn-reload').onclick = () => (active()?.loading ? moon.send('nav:stop') : moon.send('nav:reload'));
$('#btn-home').onclick = () => moon.send('nav:home');
$('#btn-star').onclick = () => moon.send('bookmark:toggle');
$('#btn-tasks').onclick = () => moon.send('tasks:open');
$('#btn-panel').onclick = () => moon.send('panel:set', !state.panelOpen);
$('#btn-shield').onclick = () => { section = 'shield'; moon.send('panel:set', true); renderPanel(); };
$('#btn-blocked').onclick = () => { section = 'shield'; moon.send('panel:set', true); renderPanel(); };
$('#zoom').onclick = () => moon.send('zoom', 0);

const addr = $('#address');
addr.addEventListener('focus', () => { editingAddress = true; setTimeout(() => addr.select(), 0); });
addr.addEventListener('blur', () => { editingAddress = false; render(); });
addr.addEventListener('keydown', e => { if (e.key === 'Escape') { addr.blur(); } });
$('#omnibox').addEventListener('submit', e => {
  e.preventDefault();
  const v = addr.value.trim();
  if (!v) return;
  moon.send('nav:go', v);
  addr.blur();
});

document.querySelectorAll('.panel-tabs button').forEach(b => b.onclick = () => { section = b.dataset.sec; renderPanel(); });

moon.on('state', s => { state = s; render(); });
moon.on('focus-address', () => addr.focus());
moon.on('panel', sec => { section = sec; renderPanel(); });
let toastTimer;
moon.on('toast', ({ msg, kind }) => {
  const t = $('#toast');
  t.textContent = msg; t.className = kind || ''; t.hidden = false;
  t.style.animation = 'none'; void t.offsetWidth; t.style.animation = '';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), kind === 'danger' ? 6000 : 3000);
});

const active = () => state.tabs.find(t => t.id === state.activeId);

// ───────── çizim ─────────
let lastPanelKey = '';
function render() {
  renderTabs();
  const t = active();
  document.body.classList.toggle('priv-active', !!t?.priv);
  document.body.classList.toggle('panel-open', !!state.panelOpen);
  $('#btn-back').disabled = !t?.canBack;
  $('#btn-fwd').disabled = !t?.canFwd;
  $('#btn-reload').innerHTML = t?.loading ? I.stop : I.reload;
  $('#btn-reload').title = t?.loading ? 'Durdur' : 'Yenile (Ctrl+R)';
  if (!editingAddress) addr.value = t?.url || '';
  addr.placeholder = t?.priv ? 'Gizli arama — geçmişe kaydedilmez' : 'Ara veya adres yaz…';

  const sh = t?.shield || { level: 'internal', score: 0 };
  const sb = $('#btn-shield');
  sb.className = 'shield ' + sh.level;
  const label = { safe: t?.url?.startsWith('https') ? 'Güvenli' : 'Korumalı', caution: 'Dikkat', danger: 'Tehlike', internal: 'Moon' }[sh.level];
  sb.innerHTML = (sh.level === 'safe' ? (t?.url?.startsWith('https') ? I.lock : I.shieldOk) : sh.level === 'internal' ? I.moon : I.shieldWarn) + `<span>${label}</span>`;
  sb.title = `Ay Kalkanı — risk puanı ${sh.score || 0}/100` + (t?.pageWarn ? '\n' + t.pageWarn : '');

  const isBm = t?.url && state.bookmarks.some(b => b.url === t.url);
  $('#btn-star').innerHTML = isBm ? I.starFill : I.star;
  $('#btn-star').classList.toggle('on', !!isBm);
  $('#btn-star').hidden = !t?.url?.startsWith('http');

  $('#blocked-n').textContent = t?.blocked ?? 0;
  $('#btn-blocked').classList.toggle('off', !state.settings.adblock);

  const z = $('#zoom');
  z.hidden = !t || t.zoom === 100;
  if (t) z.textContent = t.zoom + '%';

  const p = $('#progress');
  if (t?.loading) { p.style.opacity = 1; p.style.width = '70%'; }
  else { p.style.width = '100%'; p.style.opacity = 0; setTimeout(() => { if (!active()?.loading) p.style.width = '0'; }, 400); }

  renderBookmarks();
  $('#panel').hidden = !state.panelOpen;
  $('#btn-panel').classList.toggle('on', !!state.panelOpen);
  if (state.panelOpen) {
    // panel yalnızca içeriği değiştiyse yeniden çizilir (yazarken odak kaybolmasın)
    if (panelKey() !== lastPanelKey) renderPanel();
  }
}

let dragFrom = null;
function renderTabs() {
  const box = $('#tabs');
  box.innerHTML = state.tabs.map((t, i) => `
    <div class="tab ${t.id === state.activeId ? 'active' : ''} ${t.priv ? 'priv' : ''}" data-id="${t.id}" data-i="${i}" draggable="true" title="${esc(t.title)}${t.url ? '\n' + esc(t.url) : ''}">
      ${t.shield?.level === 'danger' ? '<span class="dot"></span>' : ''}
      <span class="fav ${t.loading ? 'spin' : ''}">${t.priv ? I.mask : t.favicon && /^https:/.test(t.favicon) ? `<img src="${esc(t.favicon)}" alt="">` : (t.url ? I.globe : I.moon)}</span>
      <span class="title">${esc(t.title)}</span>
      <button class="x" data-close="${t.id}" title="Kapat (Ctrl+W)">${I.close}</button>
    </div>`).join('');
  box.querySelectorAll('.fav img').forEach(img => img.onerror = () => { img.replaceWith(document.createRange().createContextualFragment(I.globe)); });
  box.querySelectorAll('.tab').forEach(el => {
    el.onmousedown = e => { if (e.button === 0 && !e.target.closest('.x')) moon.send('tab:activate', el.dataset.id); };
    el.onauxclick = e => { if (e.button === 1) moon.send('tab:close', el.dataset.id); };
    el.ondragstart = () => { dragFrom = +el.dataset.i; el.classList.add('dragging'); };
    el.ondragend = () => el.classList.remove('dragging');
    el.ondragover = e => e.preventDefault();
    el.ondrop = e => { e.preventDefault(); if (dragFrom !== null) moon.send('tab:move', dragFrom, +el.dataset.i); dragFrom = null; };
  });
  box.querySelectorAll('.x').forEach(b => b.onclick = e => { e.stopPropagation(); moon.send('tab:close', b.dataset.close); });
}

function renderBookmarks() {
  const bar = $('#bookmarks');
  if (!state.bookmarks.length) { bar.innerHTML = '<span class="bm-empty">Yer imi eklemek için ⭐ simgesine veya Ctrl+D\'ye basın</span>'; return; }
  bar.innerHTML = state.bookmarks.map(b => `<button class="bm" data-u="${esc(b.url)}" title="${esc(b.url)}"><span class="l">${letter(b.title)}</span><span>${esc(b.title)}</span></button>`).join('');
  bar.querySelectorAll('.bm').forEach(b => {
    b.onclick = () => moon.send('bookmark:open', b.dataset.u);
    b.onauxclick = e => { if (e.button === 1) moon.send('tab:new', { url: b.dataset.u }); };
  });
}

// ───────── panel ─────────
const sw = (key, on) => `<button class="switch ${on ? 'on' : ''}" data-key="${key}" aria-pressed="${on}"></button>`;

async function renderPanel() {
  const t = active();
  lastPanelKey = panelKey();
  document.querySelectorAll('.panel-tabs button').forEach(b => b.classList.toggle('sel', b.dataset.sec === section));
  const body = $('#panel-body');
  const s = state.settings;

  if (section === 'shield') {
    const sh = t?.shield || { level: 'internal', score: 0, reasons: [] };
    const title = { safe: 'Tehdit tespit edilmedi', caution: 'Dikkatli olun', danger: 'Tehlikeli sayfa', internal: 'MoonBrowser iç sayfası' }[sh.level];
    const icon = sh.level === 'safe' ? I.shieldOk : sh.level === 'internal' ? I.moon : I.shieldWarn;
    body.innerHTML = `
      <div class="card">
        <h4>Ay Kalkanı · bu sayfa</h4>
        <div class="verdict ${sh.level}"><div class="big">${icon}</div><div><strong>${title}</strong><small>${esc(t?.url ? hostOf(t.url) : 'Yeni sekme')}</small></div></div>
        ${sh.level !== 'internal' ? `<div class="meter"><i style-w="${sh.score}"></i></div><small class="dim">Risk puanı ${sh.score}/100</small>` : ''}
        ${sh.reasons?.length ? `<ul class="reasons">${sh.reasons.map(r => `<li><span>${esc(r.why)}</span>${r.pts ? `<b>+${r.pts}</b>` : ''}</li>`).join('')}</ul>` : ''}
      </div>
      <div class="card">
        <h4>Koruma istatistikleri</h4>
        <div class="stats">
          <div class="stat"><b>${t?.blocked ?? 0}</b><span>Bu sayfada engel</span></div>
          <div class="stat"><b>${fmt(state.stats.blocked)}</b><span>Toplam engel</span></div>
          <div class="stat"><b>${fmt(state.stats.threats)}</b><span>Durdurulan tehdit</span></div>
        </div>
      </div>
      <div class="card">
        <h4>Hızlı korumalar</h4>
        <div class="row"><div class="lbl">Reklam & izleyici engelleyici<small>100+ reklam/izleme ağı ve kripto madencisi</small></div>${sw('adblock', s.adblock)}</div>
        <div class="row"><div class="lbl">Yalnızca HTTPS<small>Şifresiz bağlantıları otomatik yükseltir</small></div>${sw('httpsOnly', s.httpsOnly)}</div>
        <div class="row"><div class="lbl">Ay Kalkanı seviyesi<small>Sıkı: şüpheli siteler açılmadan durdurulur</small></div>
          <select class="sel" data-key="shield"><option value="strict">Sıkı</option><option value="balanced">Dengeli</option><option value="off">Kapalı</option></select></div>
      </div>`;
    const bar = body.querySelector('.meter i');
    if (bar) bar.style.width = Math.max(3, sh.score) + '%';
  }

  if (section === 'bookmarks') {
    body.innerHTML = state.bookmarks.length ? state.bookmarks.map(b => `
      <div class="list-item"><span class="l">${letter(b.title)}</span>
        <div class="t" data-open="${esc(b.url)}"><b>${esc(b.title)}</b><small>${esc(b.url)}</small></div>
        <div class="acts"><button class="ico sm" data-ren="${esc(b.url)}" title="Yeniden adlandır">${I.edit}</button><button class="ico sm" data-del="${esc(b.url)}" title="Sil">${I.trash}</button></div>
      </div>`).join('') : '<div class="empty">Henüz yer imi yok.<br>Bir sayfadayken ⭐ simgesine basın.</div>';
    body.querySelectorAll('[data-open]').forEach(el => el.onclick = () => moon.send('bookmark:open', el.dataset.open));
    body.querySelectorAll('[data-del]').forEach(el => el.onclick = () => moon.send('bookmark:remove', el.dataset.del));
    body.querySelectorAll('[data-ren]').forEach(el => el.onclick = () => {
      const item = el.closest('.list-item').querySelector('b');
      item.contentEditable = 'true'; item.focus();
      document.getSelection().selectAllChildren(item);
      const done = () => { item.contentEditable = 'false'; moon.send('bookmark:rename', el.dataset.ren, item.textContent.trim()); };
      item.onblur = done;
      item.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); item.blur(); } };
    });
  }

  if (section === 'history') {
    const list = await moon.invoke('history:get');
    body.innerHTML = `<input class="search" id="hq" placeholder="Geçmişte ara…"><div id="hl"></div>
      <div class="btns"><button class="btn danger" id="hclear">Tüm geçmişi temizle</button></div>`;
    const draw = q => {
      q = q.toLowerCase();
      const items = list.filter(h => !q || h.title.toLowerCase().includes(q) || h.url.toLowerCase().includes(q)).slice(0, 300);
      let lastDay = '';
      $('#hl').innerHTML = items.length ? items.map(h => {
        const d = new Date(h.t);
        const day = d.toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
        const head = day !== lastDay ? `<div class="day">${day}</div>` : '';
        lastDay = day;
        return head + `<div class="list-item"><span class="l">${letter(hostOf(h.url))}</span>
          <div class="t" data-open="${esc(h.url)}"><b>${esc(h.title)}</b><small>${d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })} · ${esc(hostOf(h.url))}</small></div>
          <div class="acts"><button class="ico sm" data-del="${esc(h.url)}" title="Sil">${I.trash}</button></div></div>`;
      }).join('') : '<div class="empty">Geçmiş boş</div>';
      $('#hl').querySelectorAll('[data-open]').forEach(el => el.onclick = () => moon.send('bookmark:open', el.dataset.open));
      $('#hl').querySelectorAll('[data-del]').forEach(el => el.onclick = () => {
        moon.send('history:remove', el.dataset.del);
        list.splice(0, list.length, ...list.filter(h => h.url !== el.dataset.del));
        draw($('#hq').value);
      });
    };
    draw('');
    $('#hq').oninput = e => draw(e.target.value);
    $('#hclear').onclick = () => { moon.send('history:clear'); list.length = 0; draw(''); };
  }

  if (section === 'settings') {
    const scenes = [['auto', 'Otomatik'], ['nebula', 'Bulutsu'], ['aurora', 'Kutup ışığı'], ['moonrise', 'Ay doğuşu'], ['eclipse', 'Tutulma'], ['galaxy', 'Galaksi'], ['custom', 'Kendi resmim']];
    body.innerHTML = `
      <div class="card"><h4>Yeni sekme arka planı</h4>
        <div class="scenes">${scenes.map(([k, n]) => `<button class="scene sc-${k} ${s.background === k ? 'sel' : ''}" data-scene="${k}">${n}</button>`).join('')}</div>
        <div class="row"><div class="lbl">Otomatik değişim aralığı<small>"Otomatik" seçiliyken sahneler arası geçiş</small></div>
          <select class="sel" data-key="bgInterval" data-num="1"><option value="10">10 sn</option><option value="25">25 sn</option><option value="60">1 dk</option><option value="300">5 dk</option></select></div>
      </div>
      <div class="card"><h4>Arama</h4>
        <div class="row"><div class="lbl">Arama motoru</div>
          <select class="sel" data-key="engine"><option value="duckduckgo">DuckDuckGo (gizlilik)</option><option value="brave">Brave Search</option><option value="startpage">Startpage</option><option value="google">Google</option><option value="bing">Bing</option><option value="yandex">Yandex</option></select></div>
      </div>
      <div class="card"><h4>Gizlilik & güvenlik</h4>
        <div class="row"><div class="lbl">Reklam & izleyici engelleyici</div>${sw('adblock', s.adblock)}</div>
        <div class="row"><div class="lbl">Yalnızca HTTPS</div>${sw('httpsOnly', s.httpsOnly)}</div>
        <div class="row"><div class="lbl">Üçüncü taraf çerezlere izin ver<small>Kapalı = siteler arası izleme engellenir</small></div>${sw('thirdPartyCookies', s.thirdPartyCookies)}</div>
        <div class="row"><div class="lbl">"Beni izleme" sinyali gönder<small>DNT + Global Privacy Control</small></div>${sw('dnt', s.dnt)}</div>
        <div class="row"><div class="lbl">Ay Kalkanı seviyesi</div>
          <select class="sel" data-key="shield"><option value="strict">Sıkı</option><option value="balanced">Dengeli</option><option value="off">Kapalı</option></select></div>
        <div class="btns">
          <button class="btn" data-clear="cache">Önbelleği sil</button>
          <button class="btn" data-clear="cookies">Çerezleri sil</button>
          <button class="btn danger" data-clear="all">Her şeyi sil</button>
        </div>
      </div>
      <div class="card"><h4>Arka plan & görevler</h4>
        <div class="row"><div class="lbl">Kapatınca arka planda çalış<small>Tepside kalır, görev hatırlatıcıları sürer</small></div>${sw('runInBackground', s.runInBackground)}</div>
        <div class="btns"><button class="btn primary" id="open-tasks">Görev penceresini aç</button></div>
      </div>
      <div class="card"><h4>Kısayollar</h4><small class="dim">Ctrl+T yeni · Ctrl+Shift+N gizli · Ctrl+W kapat · Ctrl+L adres · Ctrl+D yer imi · Ctrl+J görevler · Ctrl+Tab sekme değiştir · Ctrl+± yakınlaştır · F11 tam ekran · F12 geliştirici</small></div>`;
    body.querySelectorAll('[data-scene]').forEach(b => b.onclick = async () => {
      if (b.dataset.scene === 'custom') { await moon.invoke('bg:pick'); return; }
      moon.send('settings:set', 'background', b.dataset.scene);
    });
    body.querySelectorAll('[data-clear]').forEach(b => b.onclick = () => moon.invoke('data:clear', b.dataset.clear));
    $('#open-tasks').onclick = () => moon.send('tasks:open');
  }

  // ortak: anahtarlar ve seçimler
  body.querySelectorAll('.switch').forEach(b => b.onclick = () => moon.send('settings:set', b.dataset.key, !state.settings[b.dataset.key]));
  body.querySelectorAll('select[data-key]').forEach(sel => {
    sel.value = String(s[sel.dataset.key]);
    sel.onchange = () => moon.send('settings:set', sel.dataset.key, sel.dataset.num ? Number(sel.value) : sel.value);
  });
}

function panelKey() {
  const t = active();
  const parts = { shield: [t?.id, t?.shield, t?.blocked, t?.url, state.stats, state.settings], bookmarks: [state.bookmarks], history: [], settings: [state.settings] };
  return JSON.stringify([section, parts[section]]);
}

function fmt(n) { n = n || 0; return n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'B' : String(n); }
