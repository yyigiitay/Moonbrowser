// Tek renkli çizgi ikonlar (currentColor)
const s = d => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
window.ICONS = {
  plus: s('<path d="M12 5v14M5 12h14"/>'),
  mask: s('<path d="M3 10c0-2 1-3 3-3h12c2 0 3 1 3 3v1c0 3-2 5-4.5 5-1.6 0-2.6-1-3.2-2.2a1.5 1.5 0 0 0-2.6 0C10.1 15 9.1 16 7.5 16 5 16 3 14 3 11z"/><circle cx="8" cy="11" r="1.3"/><circle cx="16" cy="11" r="1.3"/>'),
  back: s('<path d="M15 18l-6-6 6-6"/>'),
  fwd: s('<path d="M9 18l6-6-6-6"/>'),
  reload: s('<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>'),
  stop: s('<path d="M6 6l12 12M18 6L6 18"/>'),
  home: s('<path d="M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5a8.5 8.5 0 1 0 11 11z"/>'),
  star: s('<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>'),
  starFill: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/></svg>',
  shield: s('<path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/>'),
  shieldOk: s('<path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/>'),
  shieldWarn: s('<path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/><path d="M12 8v4M12 15.5v.01"/>'),
  moon: s('<path d="M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5a8.5 8.5 0 1 0 11 11z"/>'),
  block: s('<circle cx="12" cy="12" r="8"/><path d="M6.5 6.5l11 11"/>'),
  tasks: s('<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 9l1.5 1.5L12 8M8 15l1.5 1.5L12 14M14.5 9.5H17M14.5 15.5H17"/>'),
  panel: s('<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M15 4v16"/>'),
  close: s('<path d="M7 7l10 10M17 7L7 17"/>'),
  globe: s('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.6 3.5 5.4 3.5 8.5s-1 5.9-3.5 8.5c-2.5-2.6-3.5-5.4-3.5-8.5s1-5.9 3.5-8.5z"/>'),
  trash: s('<path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/>'),
  edit: s('<path d="M4 20h4L19 9l-4-4L4 16z"/>'),
  lock: s('<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>')
};
