'use strict';
const $ = s => document.querySelector(s);
const COLORS = ['#a99cff', '#ffd98a', '#6ee7b7', '#7dd3fc', '#fb7185', '#f0abfc'];
let tasks = [], prefs = { accent: '#a99cff', opacity: 0.97, pinned: false }, filter = 'open';

async function load() {
  const r = await moon.invoke('tasks:get');
  if (!r) return;
  tasks = r.tasks || []; prefs = r.prefs || prefs;
  applyPrefs(); render();
}
const save = () => moon.send('tasks:save', tasks);
const savePrefs = () => { moon.send('tasks:prefs', prefs); applyPrefs(); };

function applyPrefs() {
  document.documentElement.style.setProperty('--accent', prefs.accent);
  $('#opacity').value = Math.round(prefs.opacity * 100);
  $('#pin').classList.toggle('on', !!prefs.pinned);
  $('#swatches').innerHTML = '';
  for (const c of COLORS) {
    const b = document.createElement('button');
    b.className = 'sw' + (c === prefs.accent ? ' sel' : ''); b.style.background = c; b.title = c;
    b.onclick = () => { prefs.accent = c; savePrefs(); };
    $('#swatches').append(b);
  }
}

$('#btn-custom').onclick = () => { $('#custom').hidden = !$('#custom').hidden; };
$('#opacity').oninput = e => { prefs.opacity = e.target.value / 100; savePrefs(); };
$('#pin').onclick = () => { prefs.pinned = !prefs.pinned; savePrefs(); };

const toLocalInput = d => { const p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; };
document.querySelectorAll('.quick button').forEach(b => b.onclick = () => {
  const d = new Date(); const q = b.dataset.q;
  if (q === 'tonight') { d.setHours(20, 0, 0, 0); if (d < new Date()) d.setDate(d.getDate() + 1); }
  else if (q === 'tomorrow') { d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); }
  else d.setMinutes(d.getMinutes() + Number(q));
  $('#t-due').value = toLocalInput(d);
  $('#t-title').focus();
});

$('#add').addEventListener('submit', e => {
  e.preventDefault();
  const title = $('#t-title').value.trim();
  if (!title) return;
  const dueStr = $('#t-due').value;
  tasks.unshift({
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title, note: '',
    due: dueStr ? new Date(dueStr).getTime() : null, priority: $('#t-pri').value, cat: $('#t-cat').value.trim(),
    repeat: $('#t-repeat').value, done: false, notified: false, created: Date.now()
  });
  $('#t-title').value = ''; $('#t-due').value = ''; $('#t-repeat').value = 'none';
  save(); render();
});

document.querySelectorAll('#filters button').forEach(b => b.onclick = () => {
  filter = b.dataset.f;
  document.querySelectorAll('#filters button').forEach(x => x.classList.toggle('sel', x === b));
  render();
});

function fmtDue(ts) {
  const d = new Date(ts), now = new Date();
  const same = d.toDateString() === now.toDateString();
  const tmr = new Date(now); tmr.setDate(now.getDate() + 1);
  const time = d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  if (same) return 'Bugün ' + time;
  if (d.toDateString() === tmr.toDateString()) return 'Yarın ' + time;
  return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }) + ' ' + time;
}

function render() {
  const now = Date.now();
  const endToday = new Date(); endToday.setHours(23, 59, 59, 999);
  const rank = { high: 0, mid: 1, low: 2 };
  let list = tasks.filter(t =>
    filter === 'open' ? !t.done : filter === 'done' ? t.done : filter === 'today' ? !t.done && t.due && t.due <= endToday.getTime() : true);
  list.sort((a, b) => (a.done - b.done) || ((a.due || 9e15) - (b.due || 9e15)) || (rank[a.priority] - rank[b.priority]));

  const open = tasks.filter(t => !t.done).length;
  const late = tasks.filter(t => !t.done && t.due && t.due < now).length;
  $('#summary').textContent = `${open} açık görev` + (late ? ` · ${late} gecikmiş` : '');
  $('#cats').innerHTML = '';
  for (const c of [...new Set(tasks.map(t => t.cat).filter(Boolean))]) { const o = document.createElement('option'); o.value = c; $('#cats').append(o); }

  const ul = $('#list');
  ul.innerHTML = '';
  if (!list.length) { ul.innerHTML = '<li class="empty">🌙 Burada görev yok</li>'; return; }
  for (const t of list) {
    const li = document.createElement('li');
    li.className = `task ${t.priority} ${t.done ? 'done' : ''} ${!t.done && t.due && t.due < now ? 'late' : ''}`;
    const chk = document.createElement('button'); chk.className = 'chk'; chk.textContent = t.done ? '✓' : ''; chk.title = 'Tamamla';
    chk.onclick = () => { t.done = !t.done; save(); render(); };
    const body = document.createElement('div'); body.className = 'body';
    const tt = document.createElement('div'); tt.className = 'tt'; tt.textContent = t.title; tt.contentEditable = 'true'; tt.spellcheck = false;
    tt.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); tt.blur(); } };
    tt.onblur = () => { const v = tt.textContent.trim(); if (v && v !== t.title) { t.title = v; save(); } else tt.textContent = t.title; };
    const meta = document.createElement('div'); meta.className = 'meta';
    if (t.due) { const s = document.createElement('span'); s.className = 'due'; s.textContent = '⏰ ' + fmtDue(t.due) + (t.repeat === 'daily' ? ' · her gün' : t.repeat === 'weekly' ? ' · her hafta' : ''); meta.append(s); }
    if (t.cat) { const s = document.createElement('span'); s.className = 'tag'; s.textContent = '#' + t.cat; meta.append(s); }
    body.append(tt, meta);
    const del = document.createElement('button'); del.className = 'del'; del.textContent = '✕'; del.title = 'Sil';
    del.onclick = () => { tasks = tasks.filter(x => x !== t); save(); render(); };
    li.append(chk, body, del);
    ul.append(li);
  }
}

moon.on('tasks:changed', load);
setInterval(render, 30000);
load();
