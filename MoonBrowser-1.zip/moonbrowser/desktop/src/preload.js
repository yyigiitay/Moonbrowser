'use strict';
// Arayüz ile ana süreç arasındaki tek köprü — yalnızca beyaz listedeki kanallar.
const { contextBridge, ipcRenderer } = require('electron');

const SEND = new Set([
  'tab:new', 'tab:close', 'tab:activate', 'tab:move', 'nav:go', 'nav:back', 'nav:forward', 'nav:reload', 'nav:stop', 'nav:home',
  'bookmark:toggle', 'bookmark:remove', 'bookmark:rename', 'bookmark:open', 'panel:set', 'tasks:open', 'shield:explain', 'zoom',
  'settings:set', 'history:clear', 'history:remove', 'tasks:save', 'tasks:prefs'
]);
const INVOKE = new Set(['history:get', 'bg:pick', 'data:clear', 'tasks:get']);
const LISTEN = new Set(['state', 'toast', 'focus-address', 'panel', 'tasks:changed']);

contextBridge.exposeInMainWorld('moon', {
  platform: process.platform,
  send: (ch, ...args) => { if (SEND.has(ch)) ipcRenderer.send(ch, ...args); },
  invoke: (ch, ...args) => (INVOKE.has(ch) ? ipcRenderer.invoke(ch, ...args) : Promise.reject(new Error('izinsiz kanal'))),
  on: (ch, fn) => { if (LISTEN.has(ch)) ipcRenderer.on(ch, (_e, data) => fn(data)); }
});
