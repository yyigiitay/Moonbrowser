'use strict';
const {
  app, BrowserWindow, WebContentsView, ipcMain, session, Menu, Tray, dialog,
  Notification, shell, clipboard, nativeImage
} = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { analyzeUrl, getSite } = require('./shield');
const { isAdHost, COSMETIC_CSS } = require('./adblock');
const Store = require('./store');

// ───────────────────────── Sabitler ─────────────────────────
const PAGES = path.join(__dirname, 'pages');
const PAGES_URL = pathToFileURL(PAGES).href;
const ICON = path.join(__dirname, '..', 'assets', 'icon.png');
const TOP = 116;          // sekme çubuğu + araç çubuğu + yer imi çubuğu (ui.css ile aynı)
const PANEL_W = 340;      // yan panel genişliği
const SEARCH = {
  duckduckgo: 'https://duckduckgo.com/?q=',
  google: 'https://www.google.com/search?q=',
  brave: 'https://search.brave.com/search?q=',
  startpage: 'https://www.startpage.com/do/search?q=',
  yandex: 'https://yandex.com.tr/search/?text=',
  bing: 'https://www.bing.com/search?q='
};
const DANGEROUS_EXT = /\.(exe|msi|bat|cmd|com|scr|pif|vbs|vbe|js|jse|wsf|wsh|ps1|psm1|hta|cpl|jar|apk|dmg|pkg|sh|reg|lnk|iso|img|docm|xlsm|pptm)$/i;
const SAFE_PERMS = new Set(['fullscreen', 'clipboard-sanitized-write', 'pointerLock']);
const PERM_TR = {
  media: 'kamera / mikrofon', geolocation: 'konum', notifications: 'bildirim', 'clipboard-read': 'pano okuma',
  midi: 'MIDI cihazları', midiSysex: 'MIDI cihazları', openExternal: 'harici uygulama açma', 'display-capture': 'ekran paylaşımı',
  idleDetection: 'boşta algılama', 'window-management': 'pencere yönetimi', hid: 'USB/HID cihazları', serial: 'seri port', usb: 'USB cihazları'
};

// ───────────────────────── Tek örnek & sertleştirme ─────────────────────────
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
app.enableSandbox();
app.commandLine.appendSwitch('disable-features', 'InterestFeedContentSuggestions');
app.commandLine.appendSwitch('enable-features', 'StrictOriginIsolation');

const store = new Store(path.join(app.getPath('userData'), 'moon-data.json'), {
  settings: {
    adblock: true, httpsOnly: true, shield: 'strict', engine: 'duckduckgo', thirdPartyCookies: false,
    dnt: true, background: 'auto', bgInterval: 25, customBg: '', runInBackground: false, permissions: {}
  },
  taskPrefs: { accent: '#a99cff', opacity: 0.97, pinned: false },
  bookmarks: [
    { title: 'Wikipedia', url: 'https://tr.wikipedia.org/' },
    { title: 'GitHub', url: 'https://github.com/' },
    { title: 'Claude', url: 'https://claude.ai/' }
  ],
  history: [],
  tasks: [],
  stats: { blocked: 0, threats: 0, upgraded: 0 }
});
const S = () => store.get('settings');

let win = null, tasksWin = null, tray = null, quitting = false;
const tabs = new Map();
let activeId = null, nextId = 1, panelOpen = false, fullscreenTab = null;
const httpExceptions = new Set();   // kullanıcının HTTP'ye izin verdiği siteler (oturumluk)
const wcToTab = new Map();          // webContents.id -> tab

// ───────────────────────── Oturumlar (normal + gizli) ─────────────────────────
const configured = new WeakSet();
function mainSession() { const s = session.fromPartition('persist:moon'); configure(s, false); return s; }
function privateSession() { const s = session.fromPartition('moon-private'); configure(s, true); return s; }

function configure(ses, isPrivate) {
  if (configured.has(ses)) return;
  configured.add(ses);

  ses.setUserAgent(ses.getUserAgent().replace(/ Electron\/\S+/, '').replace(/ moonbrowser\/\S+/i, ''));
  ses.setSpellCheckerEnabled(false);

  // 1) Reklam/izleyici engeli + 2) HTTPS-zorunlu yükseltme
  ses.webRequest.onBeforeRequest((d, cb) => {
    let u;
    try { u = new URL(d.url); } catch { return cb({}); }
    const tab = wcToTab.get(d.webContentsId);
    if (S().adblock && d.resourceType !== 'mainFrame' && isAdHost(u.hostname)) {
      if (tab) { tab.blocked++; bump('blocked'); scheduleState(); }
      return cb({ cancel: true });
    }
    if (u.protocol === 'http:' && S().httpsOnly && !isLocal(u.hostname) && !httpExceptions.has(u.hostname)) {
      u.protocol = 'https:';
      if (d.resourceType === 'mainFrame') bump('upgraded');
      return cb({ redirectURL: u.href });
    }
    cb({});
  });

  // 3) İzlenmeme sinyalleri + üçüncü taraf çerez engeli
  ses.webRequest.onBeforeSendHeaders((d, cb) => {
    const h = d.requestHeaders;
    if (S().dnt) { h['DNT'] = '1'; h['Sec-GPC'] = '1'; }
    if (!S().thirdPartyCookies && isThirdParty(d)) delete h['Cookie'];
    cb({ requestHeaders: h });
  });
  ses.webRequest.onHeadersReceived((d, cb) => {
    if (!S().thirdPartyCookies && isThirdParty(d) && d.responseHeaders) {
      for (const k of Object.keys(d.responseHeaders)) if (k.toLowerCase() === 'set-cookie') delete d.responseHeaders[k];
    }
    cb({ responseHeaders: d.responseHeaders });
  });

  // 4) İzinler: güvenli olanlar hariç her şey sorulur, varsayılan RET
  ses.setPermissionRequestHandler((wc, permission, cb, details) => {
    if (SAFE_PERMS.has(permission)) return cb(true);
    let origin = '';
    try { origin = new URL(details.requestingUrl || wc.getURL()).origin; } catch { return cb(false); }
    const key = `${origin}|${permission}`;
    const saved = S().permissions[key];
    if (!isPrivate && saved !== undefined) return cb(saved);
    const name = PERM_TR[permission] || permission;
    dialog.showMessageBox(win, {
      type: 'question', title: 'İzin isteği', buttons: ['Reddet', 'İzin ver'], defaultId: 0, cancelId: 0,
      message: `${origin} sitesi ${name} izni istiyor.`,
      detail: isPrivate ? 'Gizli sekmede karar kaydedilmez.' : 'Kararınız bu site için hatırlanacak (Ayarlar > Verileri temizle ile sıfırlanır).',
      checkboxLabel: isPrivate ? undefined : 'Hatırla', checkboxChecked: true
    }).then(r => {
      const ok = r.response === 1;
      if (!isPrivate && r.checkboxChecked) { S().permissions[key] = ok; store.save(); }
      cb(ok);
    }).catch(() => cb(false));
  });
  ses.setPermissionCheckHandler((wc, permission, origin) => {
    if (SAFE_PERMS.has(permission)) return true;
    return !isPrivate && S().permissions[`${origin}|${permission}`] === true;
  });
  ses.setDevicePermissionHandler(() => false);

  // 5) İndirme güvenliği
  ses.on('will-download', (e, item) => {
    const name = item.getFilename();
    const risk = analyzeUrl(item.getURL());
    if (DANGEROUS_EXT.test(name) || risk.level !== 'safe') {
      const choice = dialog.showMessageBoxSync(win, {
        type: 'warning', title: 'Ay Kalkanı — riskli indirme', buttons: ['İndirmeyi iptal et', 'Riski anlıyorum, indir'],
        defaultId: 0, cancelId: 0,
        message: `"${name}" bilgisayarınızda çalıştırılabilir veya riskli bir dosya.`,
        detail: `Kaynak: ${item.getURL().slice(0, 140)}\nGüvenmediğiniz kaynaklardan bu tür dosyaları açmayın.` +
          (risk.reasons.length ? `\n\nAdres riskleri:\n• ${risk.reasons.map(r => r.why).join('\n• ')}` : '')
      });
      if (choice !== 1) { item.cancel(); toast('İndirme engellendi: ' + name, 'danger'); return; }
    }
    item.setSavePath(uniquePath(path.join(app.getPath('downloads'), name)));
    toast('İndiriliyor: ' + name);
    item.once('done', (_e, state) => {
      if (state === 'completed') {
        toast('İndirildi: ' + name, 'safe');
        if (Notification.isSupported()) new Notification({ title: 'İndirme tamamlandı', body: name, icon: ICON }).show();
      } else if (state !== 'cancelled') toast('İndirme başarısız: ' + name, 'danger');
    });
  });
}

function isLocal(host) {
  return host === 'localhost' || host.endsWith('.local') || /^127\./.test(host) || /^10\./.test(host) ||
    /^192\.168\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host) || host === '[::1]';
}
function isThirdParty(d) {
  if (d.resourceType === 'mainFrame') return false;
  try {
    const top = d.webContents ? d.webContents.getURL() : d.referrer;
    if (!top || !top.startsWith('http')) return false;
    return getSite(new URL(top).hostname) !== getSite(new URL(d.url).hostname);
  } catch { return false; }
}
function uniquePath(p) {
  if (!fs.existsSync(p)) return p;
  const { dir, name, ext } = path.parse(p);
  for (let i = 1; ; i++) { const c = path.join(dir, `${name} (${i})${ext}`); if (!fs.existsSync(c)) return c; }
}
function bump(k) { const st = store.get('stats'); st[k] = (st[k] || 0) + 1; store.save(); }

// ───────────────────────── Adres çözümleme & Kalkan ─────────────────────────
function resolveInput(text) {
  text = String(text || '').trim();
  if (!text || text === 'moon://newtab') return 'moon://newtab';
  if (/^moon:\/\//i.test(text)) return text.toLowerCase();
  if (/^https?:\/\//i.test(text)) return text;
  if (/^(javascript|data|file|vbscript|chrome|devtools):/i.test(text)) return SEARCH[S().engine] + encodeURIComponent(text);
  if (!/\s/.test(text) && (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(text) || /^localhost(:\d+)?(\/.*)?$/.test(text))) {
    return (/^localhost/.test(text) ? 'http://' : 'https://') + text;
  }
  return (SEARCH[S().engine] || SEARCH.duckduckgo) + encodeURIComponent(text);
}

function threshold() { return S().shield === 'strict' ? 45 : S().shield === 'balanced' ? 65 : 999; }

function verdictFor(tab, url) {
  const r = analyzeUrl(url);
  let host = '';
  try { host = new URL(url).hostname; } catch { /* yok */ }
  const block = r.score >= threshold() && !tab.bypass.has(host);
  return { ...r, block };
}

function pageUrl(file, query) {
  const u = new URL(PAGES_URL + '/' + file);
  for (const [k, v] of Object.entries(query || {})) u.searchParams.set(k, typeof v === 'string' ? v : JSON.stringify(v));
  return u.href;
}
function isOurPage(url) { return url.startsWith(PAGES_URL + '/'); }

function newtabQuery(tab) {
  const s = S();
  return {
    bg: s.background, interval: String(s.bgInterval), engine: s.engine, priv: tab.priv ? '1' : '0',
    custom: s.customBg ? pathToFileURL(s.customBg).href : '',
    bm: store.get('bookmarks').slice(0, 8).map(b => ({ t: b.title, u: b.url }))
  };
}

function showGuard(tab, url, info) {
  bump('threats');
  tab.view.webContents.loadURL(pageUrl('guard.html', {
    mode: 'threat', url, score: String(info.score), reasons: info.reasons.map(r => r.why)
  })).catch(() => { });
  toast('Ay Kalkanı tehlikeli bir sayfayı durdurdu', 'danger');
}

function navigate(tab, input) {
  const url = resolveInput(input);
  if (url.startsWith('moon://')) {
    if (url === 'moon://settings') { setPanel(true, 'settings'); return; }
    if (url === 'moon://tasks') { openTasks(); return; }
    tab.view.webContents.loadURL(pageUrl('newtab.html', newtabQuery(tab))).catch(() => { });
    return;
  }
  const v = verdictFor(tab, url);
  if (v.block) return showGuard(tab, url, v);
  tab.view.webContents.loadURL(url).catch(() => { });
}

// ───────────────────────── Sekmeler ─────────────────────────
function createTab(url, { priv = false, background = false } = {}) {
  const ses = priv ? privateSession() : mainSession();
  const view = new WebContentsView({
    webPreferences: {
      session: ses, sandbox: true, contextIsolation: true, nodeIntegration: false, nodeIntegrationInSubFrames: false,
      webSecurity: true, allowRunningInsecureContent: false, safeDialogs: true, safeDialogsMessage: 'Bu sayfanın yeni iletişim kutuları açmasını engelle',
      navigateOnDragDrop: false, spellcheck: false, webviewTag: false, autoplayPolicy: 'document-user-activation-required'
    }
  });
  view.setBackgroundColor('#0b0d1a');
  const tab = {
    id: nextId++, view, priv, title: priv ? 'Gizli Sekme' : 'Yeni Sekme', url: '', favicon: '', loading: false,
    blocked: 0, shield: { level: 'internal', score: 0, reasons: [] }, bypass: new Set(), pageWarn: ''
  };
  tabs.set(tab.id, tab);
  wcToTab.set(view.webContents.id, tab);
  wireTab(tab);
  win.contentView.addChildView(view);
  view.setVisible(false);
  navigate(tab, url || 'moon://newtab');
  if (!background) activate(tab.id); else layout();
  scheduleState();
  return tab;
}

function activate(id) {
  if (!tabs.has(id)) return;
  activeId = id;
  for (const t of tabs.values()) t.view.setVisible(t.id === id);
  layout();
  const t = tabs.get(id);
  t.view.webContents.focus();
  scheduleState();
}

function closeTab(id) {
  const t = tabs.get(id);
  if (!t) return;
  const order = [...tabs.keys()];
  const idx = order.indexOf(id);
  win.contentView.removeChildView(t.view);
  wcToTab.delete(t.view.webContents.id);
  tabs.delete(id);
  try { t.view.webContents.close(); } catch { /* zaten kapalı */ }
  if (t.priv && ![...tabs.values()].some(x => x.priv)) wipePrivate();
  if (!tabs.size) { createTab(); return; }
  if (activeId === id) activate(order[idx + 1] ?? order[idx - 1] ?? [...tabs.keys()][0]);
  scheduleState();
}

async function wipePrivate() {
  const s = session.fromPartition('moon-private');
  await s.clearStorageData().catch(() => { });
  await s.clearCache().catch(() => { });
  await s.clearAuthCache().catch(() => { });
  toast('Gizli oturum verileri silindi 🌑', 'safe');
}

function layout() {
  if (!win) return;
  const [w, h] = win.getContentSize();
  for (const t of tabs.values()) {
    if (fullscreenTab === t) t.view.setBounds({ x: 0, y: 0, width: w, height: h });
    else t.view.setBounds({ x: 0, y: TOP, width: Math.max(100, w - (panelOpen ? PANEL_W : 0)), height: Math.max(100, h - TOP) });
  }
}

function setPanel(open, section) {
  panelOpen = open;
  layout();
  scheduleState();
  if (section) win.webContents.send('panel', section);
}

function displayUrl(t) {
  const u = t.view.webContents.getURL();
  if (!u || u.includes('/newtab.html')) return '';
  if (u.includes('/guard.html')) { try { return new URL(u).searchParams.get('url') || ''; } catch { return ''; } }
  return u;
}

function updateShield(t) {
  const u = t.view.webContents.getURL();
  if (!u.startsWith('http')) { t.shield = { level: 'internal', score: 0, reasons: [] }; return; }
  t.shield = analyzeUrl(u);
}

function wireTab(tab) {
  const wc = tab.view.webContents;

  wc.setWindowOpenHandler(({ url, disposition }) => {
    if (/^https?:/.test(url)) createTab(url, { priv: tab.priv, background: disposition === 'background-tab' });
    return { action: 'deny' };
  });

  const guardNav = (e, url, isRedirect) => {
    const cur = wc.getURL();
    if (isOurPage(url)) { if (isRedirect) e.preventDefault(); return; }
    if (!/^https?:/i.test(url)) {
      e.preventDefault();
      if (/^(mailto|tel):/i.test(url)) {
        dialog.showMessageBox(win, { type: 'question', buttons: ['İptal', 'Aç'], defaultId: 0, message: `Harici uygulama açılsın mı?\n${url.slice(0, 120)}` })
          .then(r => { if (r.response === 1) shell.openExternal(url); });
      }
      return;
    }
    let host = '';
    try { host = new URL(url).hostname; } catch { return e.preventDefault(); }
    if (!isRedirect && isOurPage(cur) && cur.includes('/guard.html')) {
      const mode = new URL(cur).searchParams.get('mode');
      if (mode === 'threat') tab.bypass.add(host);
      if (url.startsWith('http:')) httpExceptions.add(host);
      return;
    }
    const v = verdictFor(tab, url);
    if (v.block) { e.preventDefault(); showGuard(tab, url, v); }
  };
  wc.on('will-navigate', (e, url) => guardNav(e, url, false));
  wc.on('will-redirect', (e, url) => guardNav(e, url, true));
  wc.on('will-attach-webview', e => e.preventDefault());

  wc.on('page-title-updated', (_e, title) => { tab.title = title || tab.title; scheduleState(); });
  wc.on('page-favicon-updated', (_e, icons) => { tab.favicon = icons[0] || ''; scheduleState(); });
  wc.on('did-start-loading', () => { tab.loading = true; scheduleState(); });
  wc.on('did-stop-loading', () => { tab.loading = false; scheduleState(); });
  wc.on('did-navigate', (_e, url) => {
    tab.blocked = 0; tab.pageWarn = ''; tab.favicon = '';
    if (isOurPage(url)) tab.title = url.includes('/guard.html') ? 'Ay Kalkanı uyarısı' : (tab.priv ? 'Gizli Sekme' : 'Yeni Sekme');
    updateShield(tab);
    scheduleState();
  });
  wc.on('did-navigate-in-page', () => { updateShield(tab); scheduleState(); });

  wc.on('did-finish-load', async () => {
    const url = wc.getURL();
    if (!url.startsWith('http')) return;
    if (S().adblock) wc.insertCSS(COSMETIC_CSS, { cssOrigin: 'user' }).catch(() => { });
    if (!tab.priv) addHistory(wc.getTitle(), url);
    // Sayfa içi analiz (izole dünyada, sayfa kodu göremez)
    try {
      const res = await wc.executeJavaScriptInIsolatedWorld(999, [{
        code: `(() => {
          const pw = document.querySelectorAll('input[type=password]').length;
          const cc = document.querySelectorAll('input[autocomplete^="cc-"],input[name*="card" i],input[name*="cvv" i],input[name*="kart" i]').length;
          const insecure = [...document.forms].filter(f => (f.action||'').startsWith('http:')).length;
          return { pw, cc, insecure };
        })()`
      }]);
      if (!res) return;
      const warn = [];
      if ((res.pw || res.cc) && url.startsWith('http:')) warn.push('Şifre/kart alanı şifrelenmemiş sayfada!');
      if (res.insecure) warn.push('Form verileri şifrelenmeden gönderiliyor');
      if ((res.pw || res.cc) && tab.shield.level !== 'safe') warn.push('Şüpheli adreste şifre/kart bilgisi isteniyor — DİKKAT');
      if (warn.length) {
        tab.pageWarn = warn.join(' · ');
        tab.shield = { ...tab.shield, level: tab.shield.level === 'safe' ? 'caution' : 'danger', reasons: [...tab.shield.reasons, ...warn.map(w => ({ pts: 0, why: w }))] };
        toast(warn[0], 'danger');
        scheduleState();
      }
    } catch { /* sayfa kapanmış olabilir */ }
  });

  wc.on('did-fail-load', (_e, code, desc, url, isMain) => {
    if (!isMain || code === -3 || !/^https?:/.test(url)) return;
    wc.loadURL(pageUrl('guard.html', { mode: 'error', url, code: String(code), desc, https: S().httpsOnly ? '1' : '0' })).catch(() => { });
  });
  wc.on('render-process-gone', (_e, d) => {
    if (d.reason === 'clean-exit') return;
    const last = displayUrl(tab);
    wc.loadURL(pageUrl('guard.html', { mode: 'crash', url: last, desc: d.reason })).catch(() => { });
  });

  wc.on('enter-html-full-screen', () => { fullscreenTab = tab; win.setFullScreen(true); layout(); });
  wc.on('leave-html-full-screen', () => { fullscreenTab = null; win.setFullScreen(false); layout(); });

  wc.on('context-menu', (_e, p) => {
    const items = [];
    if (p.linkURL && /^https?:/.test(p.linkURL)) {
      items.push({ label: 'Bağlantıyı yeni sekmede aç', click: () => createTab(p.linkURL, { priv: tab.priv, background: true }) });
      items.push({ label: 'Bağlantıyı gizli sekmede aç', click: () => createTab(p.linkURL, { priv: true }) });
      items.push({ label: 'Bağlantı adresini kopyala', click: () => clipboard.writeText(p.linkURL) });
      items.push({ label: 'Bağlantıyı Ay Kalkanı ile incele', click: () => explainLink(p.linkURL) });
      items.push({ type: 'separator' });
    }
    if (p.mediaType === 'image' && p.srcURL) {
      items.push({ label: 'Resmi yeni sekmede aç', click: () => createTab(p.srcURL, { priv: tab.priv }) });
      items.push({ label: 'Resmi kaydet', click: () => wc.downloadURL(p.srcURL) });
      items.push({ type: 'separator' });
    }
    if (p.isEditable) items.push({ role: 'cut', label: 'Kes' }, { role: 'copy', label: 'Kopyala' }, { role: 'paste', label: 'Yapıştır' }, { type: 'separator' });
    else if (p.selectionText) {
      const q = p.selectionText.trim().slice(0, 80);
      items.push({ role: 'copy', label: 'Kopyala' }, { label: `"${q.length > 30 ? q.slice(0, 30) + '…' : q}" için ara`, click: () => createTab(resolveInput(q), { priv: tab.priv }) }, { type: 'separator' });
    }
    items.push(
      { label: 'Geri', enabled: wc.navigationHistory.canGoBack(), click: () => wc.navigationHistory.goBack() },
      { label: 'İleri', enabled: wc.navigationHistory.canGoForward(), click: () => wc.navigationHistory.goForward() },
      { label: 'Yenile', click: () => wc.reload() },
      { type: 'separator' },
      { label: 'Öğeyi incele', click: () => wc.inspectElement(p.x, p.y) }
    );
    Menu.buildFromTemplate(items).popup({ window: win });
  });
}

function explainLink(url) {
  const r = analyzeUrl(url);
  const lv = { safe: 'Güvenli görünüyor ✅', caution: 'Dikkatli olun ⚠️', danger: 'Tehlikeli ⛔', internal: 'İç sayfa' }[r.level];
  dialog.showMessageBox(win, {
    type: r.level === 'danger' ? 'warning' : 'info', title: 'Ay Kalkanı bağlantı analizi',
    message: `${lv} — risk puanı ${r.score}/100`,
    detail: url.slice(0, 200) + '\n\n' + (r.reasons.length ? '• ' + r.reasons.map(x => `${x.why} (+${x.pts})`).join('\n• ') : 'Risk sinyali bulunamadı.')
  });
}

// ───────────────────────── Geçmiş & yer imleri ─────────────────────────
function addHistory(title, url) {
  const h = store.get('history');
  if (h[0] && h[0].url === url) { h[0].title = title; h[0].t = Date.now(); }
  else h.unshift({ title: title || url, url, t: Date.now() });
  if (h.length > 3000) h.length = 3000;
  store.save();
}

// ───────────────────────── Durum yayını ─────────────────────────
let stateTimer = null;
function scheduleState() {
  if (stateTimer) return;
  stateTimer = setTimeout(() => { stateTimer = null; sendState(); }, 40);
}
function sendState() {
  if (!win || win.isDestroyed()) return;
  const list = [...tabs.values()].map(t => {
    const wc = t.view.webContents;
    return {
      id: t.id, title: t.title, url: displayUrl(t), favicon: t.favicon, loading: t.loading, priv: t.priv,
      blocked: t.blocked, shield: t.shield, pageWarn: t.pageWarn,
      canBack: wc.navigationHistory.canGoBack(), canFwd: wc.navigationHistory.canGoForward(),
      zoom: Math.round(wc.getZoomFactor() * 100)
    };
  });
  win.webContents.send('state', {
    tabs: list, activeId, panelOpen, bookmarks: store.get('bookmarks'), settings: S(), stats: store.get('stats')
  });
  const a = tabs.get(activeId);
  if (a) win.setTitle(`${a.title} — MoonBrowser${a.priv ? ' (Gizli)' : ''}`);
}
function toast(msg, kind = 'info') { if (win && !win.isDestroyed()) win.webContents.send('toast', { msg, kind }); }

// ───────────────────────── IPC (yalnızca kendi arayüzümüzden) ─────────────────────────
const fromUI = e => win && e.sender === win.webContents;
const fromTasks = e => (tasksWin && !tasksWin.isDestroyed() && e.sender === tasksWin.webContents) || fromUI(e);
const active = () => tabs.get(activeId);
const on = (ch, fn) => ipcMain.on(ch, (e, ...a) => { if (fromUI(e)) fn(...a); });
const handle = (ch, fn) => ipcMain.handle(ch, (e, ...a) => (fromUI(e) ? fn(...a) : null));

on('tab:new', (opts = {}) => createTab(opts.url, { priv: !!opts.priv }));
on('tab:close', id => closeTab(Number(id)));
on('tab:activate', id => activate(Number(id)));
on('tab:move', (from, to) => {
  const arr = [...tabs.entries()];
  const [m] = arr.splice(Number(from), 1);
  if (!m) return;
  arr.splice(Number(to), 0, m);
  tabs.clear(); for (const [k, v] of arr) tabs.set(k, v);
  scheduleState();
});
on('nav:go', text => { const t = active(); if (t) navigate(t, text); });
on('nav:back', () => active()?.view.webContents.navigationHistory.goBack());
on('nav:forward', () => active()?.view.webContents.navigationHistory.goForward());
on('nav:reload', () => active()?.view.webContents.reload());
on('nav:stop', () => active()?.view.webContents.stop());
on('nav:home', () => { const t = active(); if (t) navigate(t, 'moon://newtab'); });
on('bookmark:toggle', () => {
  const t = active(); if (!t) return;
  const url = t.view.webContents.getURL();
  if (!/^https?:/.test(url)) return;
  const b = store.get('bookmarks');
  const i = b.findIndex(x => x.url === url);
  if (i >= 0) { b.splice(i, 1); toast('Yer imi kaldırıldı'); } else { b.push({ title: t.title, url }); toast('Yer imlerine eklendi ⭐', 'safe'); }
  store.save(); scheduleState();
});
on('bookmark:remove', url => { store.set('bookmarks', store.get('bookmarks').filter(x => x.url !== url)); scheduleState(); });
on('bookmark:rename', (url, title) => { const b = store.get('bookmarks').find(x => x.url === url); if (b) { b.title = String(title).slice(0, 80); store.save(); scheduleState(); } });
on('bookmark:open', url => { const t = active(); if (t) navigate(t, url); });
on('panel:set', open => setPanel(!!open));
on('tasks:open', () => openTasks());
on('shield:explain', url => explainLink(url));
on('zoom', dir => zoom(dir));
on('settings:set', (key, value) => {
  const s = S();
  if (!(key in s) || key === 'permissions') return;
  s[key] = value; store.save();
  if (['background', 'bgInterval', 'customBg', 'engine'].includes(key)) refreshNewtabs();
  if (key === 'runInBackground') ensureTray();
  scheduleState();
});
handle('history:get', () => store.get('history').slice(0, 800));
on('history:clear', () => { store.set('history', []); toast('Geçmiş temizlendi', 'safe'); });
on('history:remove', url => store.set('history', store.get('history').filter(h => h.url !== url)));
handle('bg:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Arka plan resmi seç', properties: ['openFile'], filters: [{ name: 'Resimler', extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  const dir = path.join(app.getPath('userData'), 'backgrounds');
  fs.mkdirSync(dir, { recursive: true });
  const dest = path.join(dir, 'custom' + path.extname(r.filePaths[0]).toLowerCase());
  fs.copyFileSync(r.filePaths[0], dest);
  S().customBg = dest; S().background = 'custom'; store.save();
  refreshNewtabs(); scheduleState();
  return dest;
});
handle('data:clear', async what => {
  const s = mainSession();
  if (what === 'all' || what === 'cookies') await s.clearStorageData();
  if (what === 'all' || what === 'cache') await s.clearCache();
  if (what === 'all') { store.set('history', []); S().permissions = {}; store.save(); }
  toast('Veriler temizlendi 🧹', 'safe');
  return true;
});

function refreshNewtabs() {
  for (const t of tabs.values()) if (t.view.webContents.getURL().includes('/newtab.html')) navigate(t, 'moon://newtab');
}
function zoom(dir) {
  const wc = active()?.view.webContents; if (!wc) return;
  const f = wc.getZoomFactor();
  wc.setZoomFactor(dir === 0 ? 1 : Math.min(3, Math.max(0.3, +(f + dir * 0.1).toFixed(2))));
  scheduleState();
}

// ───────────────────────── Görev penceresi ─────────────────────────
function openTasks() {
  if (tasksWin && !tasksWin.isDestroyed()) { tasksWin.show(); tasksWin.focus(); return; }
  const p = store.get('taskPrefs');
  tasksWin = new BrowserWindow({
    width: 390, height: 600, minWidth: 320, minHeight: 400, title: 'MoonBrowser Görevler', icon: ICON,
    backgroundColor: '#0b0d1a', alwaysOnTop: !!p.pinned, autoHideMenuBar: true, show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), sandbox: true, contextIsolation: true, nodeIntegration: false }
  });
  tasksWin.setOpacity(p.opacity || 1);
  hardenAppWindow(tasksWin);
  tasksWin.loadFile(path.join(PAGES, 'tasks.html'));
  tasksWin.once('ready-to-show', () => tasksWin.show());
  tasksWin.on('close', e => { if (!quitting) { e.preventDefault(); tasksWin.hide(); } });
}
ipcMain.handle('tasks:get', e => fromTasks(e) ? { tasks: store.get('tasks'), prefs: store.get('taskPrefs') } : null);
ipcMain.on('tasks:save', (e, list) => {
  if (!fromTasks(e) || !Array.isArray(list)) return;
  const clean = list.slice(0, 500).map(t => ({
    id: String(t.id).slice(0, 40), title: String(t.title || '').slice(0, 200), note: String(t.note || '').slice(0, 2000),
    due: t.due ? Number(t.due) : null, priority: ['low', 'mid', 'high'].includes(t.priority) ? t.priority : 'mid',
    cat: String(t.cat || '').slice(0, 30), done: !!t.done, notified: !!t.notified, created: Number(t.created) || Date.now(),
    repeat: ['none', 'daily', 'weekly'].includes(t.repeat) ? t.repeat : 'none'
  }));
  store.set('tasks', clean);
});
ipcMain.on('tasks:prefs', (e, p) => {
  if (!fromTasks(e) || !p) return;
  const prefs = {
    accent: /^#[0-9a-f]{6}$/i.test(p.accent) ? p.accent : '#a99cff',
    opacity: Math.min(1, Math.max(0.4, Number(p.opacity) || 1)), pinned: !!p.pinned
  };
  store.set('taskPrefs', prefs);
  if (tasksWin && !tasksWin.isDestroyed()) { tasksWin.setOpacity(prefs.opacity); tasksWin.setAlwaysOnTop(prefs.pinned, 'floating'); }
});

// Hatırlatıcılar: uygulama açıkken (veya arka planda tepside) her 15 sn kontrol
function checkReminders() {
  const list = store.get('tasks');
  const now = Date.now();
  let changed = false;
  for (const t of list) {
    if (t.done || !t.due || t.notified || t.due > now) continue;
    if (Notification.isSupported()) {
      const n = new Notification({ title: '🌙 Görev zamanı', body: t.title + (t.note ? '\n' + t.note.slice(0, 120) : ''), icon: ICON });
      n.on('click', () => openTasks());
      n.show();
    }
    if (t.repeat === 'daily') t.due += 86400000;
    else if (t.repeat === 'weekly') t.due += 7 * 86400000;
    else t.notified = true;
    changed = true;
  }
  if (changed) {
    store.save();
    if (tasksWin && !tasksWin.isDestroyed()) tasksWin.webContents.send('tasks:changed');
  }
}

// ───────────────────────── Pencere, menü, tepsi ─────────────────────────
function hardenAppWindow(w) {
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-navigate', e => e.preventDefault());
  w.webContents.on('will-attach-webview', e => e.preventDefault());
}

function createWindow() {
  const isMac = process.platform === 'darwin';
  win = new BrowserWindow({
    width: 1340, height: 860, minWidth: 720, minHeight: 480, title: 'MoonBrowser', icon: ICON,
    backgroundColor: '#0b0d1a', show: false,
    titleBarStyle: 'hidden',
    titleBarOverlay: isMac ? undefined : { color: '#0b0d1a', symbolColor: '#d9d6ff', height: 40 },
    trafficLightPosition: { x: 14, y: 13 },
    webPreferences: { preload: path.join(__dirname, 'preload.js'), sandbox: true, contextIsolation: true, nodeIntegration: false, spellcheck: false }
  });
  hardenAppWindow(win);
  win.loadFile(path.join(PAGES, 'ui.html'));
  win.once('ready-to-show', () => { win.show(); });
  win.webContents.once('did-finish-load', () => { createTab(); sendState(); });
  win.on('resize', layout);
  win.on('maximize', layout); win.on('unmaximize', layout);
  win.on('enter-full-screen', layout); win.on('leave-full-screen', layout);
  win.on('close', e => {
    if (!quitting && S().runInBackground) {
      e.preventDefault(); win.hide();
      if (Notification.isSupported()) new Notification({ title: 'MoonBrowser arka planda', body: 'Görev hatırlatıcıları çalışmaya devam ediyor.', icon: ICON }).show();
    }
  });
  win.on('closed', () => {
    win = null;
    for (const t of tabs.values()) { try { t.view.webContents.close(); } catch { /* */ } }
    tabs.clear(); wcToTab.clear(); activeId = null;
    if (!S().runInBackground) { quitting = true; app.quit(); }
  });
}

function buildMenu() {
  const t = () => active();
  const tpl = [
    { label: 'MoonBrowser', submenu: [
      { label: 'Yeni sekme', accelerator: 'CmdOrCtrl+T', click: () => createTab() },
      { label: 'Yeni gizli sekme', accelerator: 'CmdOrCtrl+Shift+N', click: () => createTab(null, { priv: true }) },
      { label: 'Sekmeyi kapat', accelerator: 'CmdOrCtrl+W', click: () => activeId && closeTab(activeId) },
      { label: 'Sonraki sekme', accelerator: 'Ctrl+Tab', click: () => cycle(1) },
      { label: 'Önceki sekme', accelerator: 'Ctrl+Shift+Tab', click: () => cycle(-1) },
      { type: 'separator' },
      { label: 'Adres çubuğu', accelerator: 'CmdOrCtrl+L', click: () => { win.webContents.focus(); win.webContents.send('focus-address'); } },
      { label: 'Yer imi ekle/kaldır', accelerator: 'CmdOrCtrl+D', click: () => ipcMain.emit('bookmark:toggle', { sender: win.webContents }) },
      { label: 'Görevler', accelerator: 'CmdOrCtrl+J', click: () => openTasks() },
      { label: 'Ayarlar', accelerator: 'CmdOrCtrl+,', click: () => setPanel(true, 'settings') },
      { type: 'separator' },
      { label: 'Çıkış', accelerator: 'CmdOrCtrl+Q', click: () => { quitting = true; app.quit(); } }
    ] },
    { label: 'Düzen', submenu: [
      { role: 'undo', label: 'Geri al' }, { role: 'redo', label: 'Yinele' }, { type: 'separator' },
      { role: 'cut', label: 'Kes' }, { role: 'copy', label: 'Kopyala' }, { role: 'paste', label: 'Yapıştır' }, { role: 'selectAll', label: 'Tümünü seç' }
    ] },
    { label: 'Görünüm', submenu: [
      { label: 'Yenile', accelerator: 'CmdOrCtrl+R', click: () => t()?.view.webContents.reload() },
      { label: 'Yenile', accelerator: 'F5', visible: false, click: () => t()?.view.webContents.reload() },
      { label: 'Önbelleksiz yenile', accelerator: 'CmdOrCtrl+Shift+R', click: () => t()?.view.webContents.reloadIgnoringCache() },
      { label: 'Geri', accelerator: 'Alt+Left', click: () => t()?.view.webContents.navigationHistory.goBack() },
      { label: 'İleri', accelerator: 'Alt+Right', click: () => t()?.view.webContents.navigationHistory.goForward() },
      { type: 'separator' },
      { label: 'Yakınlaştır', accelerator: 'CmdOrCtrl+=', click: () => zoom(1) },
      { label: 'Uzaklaştır', accelerator: 'CmdOrCtrl+-', click: () => zoom(-1) },
      { label: 'Gerçek boyut', accelerator: 'CmdOrCtrl+0', click: () => zoom(0) },
      { label: 'Tam ekran', accelerator: 'F11', click: () => win.setFullScreen(!win.isFullScreen()) },
      { label: 'Geliştirici araçları', accelerator: 'F12', click: () => t()?.view.webContents.toggleDevTools() }
    ] }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}
function cycle(dir) {
  const ids = [...tabs.keys()];
  if (ids.length < 2) return;
  activate(ids[(ids.indexOf(activeId) + dir + ids.length) % ids.length]);
}

function ensureTray() {
  if (tray || !S().runInBackground) return;
  tray = new Tray(nativeImage.createFromPath(ICON).resize({ width: 18, height: 18 }));
  tray.setToolTip('MoonBrowser');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'MoonBrowser\'ı göster', click: () => { if (!win) createWindow(); else win.show(); } },
    { label: 'Görevler', click: () => openTasks() },
    { type: 'separator' },
    { label: 'Tamamen kapat', click: () => { quitting = true; app.quit(); } }
  ]));
  tray.on('click', () => { if (win) win.show(); });
}

// Uygulama genelinde ek güvenlik ağı
app.on('web-contents-created', (_e, contents) => {
  contents.on('will-attach-webview', e => e.preventDefault());
});

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
app.on('before-quit', () => { quitting = true; store.flush(); });
app.on('window-all-closed', () => { if (!S().runInBackground && process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (!win) createWindow(); else win.show(); });

app.whenReady().then(() => {
  if (process.platform === 'win32') app.setAppUserModelId('net.ayyazilim.moonbrowser');
  mainSession();
  buildMenu();
  createWindow();
  ensureTray();
  setInterval(checkReminders, 15000);
  setTimeout(checkReminders, 3000);
});
