# 🌙 MoonBrowser

Güvenlik odaklı, ay temalı tarayıcı — **Windows/Mac/Linux** (Electron) ve **Android** (Kotlin) sürümleri.

## Özellikler

| | Masaüstü | Android |
|---|---|---|
| Sekmeler (sürükle-bırak sıralama, orta tıkla kapat) | ✅ | ✅ |
| Yer imleri + yer imi çubuğu, geçmiş (aranabilir) | ✅ | ✅ |
| Gizli sekme (ayrı bellek-içi oturum, kapanınca silinir) | ✅ | ✅ (WebView çoklu profil destekliyorsa) |
| Reklam & izleyici engelleyici (100+ ağ, kripto madenci, kozmetik gizleme) | ✅ | ✅ |
| **Ay Kalkanı** — yerel risk analiz motoru | ✅ | ✅ |
| Yalnızca HTTPS (otomatik yükseltme) | ✅ | ✅ |
| Üçüncü taraf çerez engeli, DNT + GPC sinyali | ✅ | ✅ / – |
| Google Safe Browsing | – | ✅ |
| İzin istekleri (kamera, konum, mikrofon…) varsayılan RET + sor | ✅ | ✅ |
| Riskli indirme uyarısı (.exe, .apk, .bat …) | ✅ | ✅ |
| Değişen arka planlar (6 sahne + kendi resmin), yıldızlar, kayan yıldız, **gerçek ay evresi** | ✅ | ✅ |
| **Görev penceresi**: hatırlatıcı, tekrar (günlük/haftalık), öncelik, etiket, renk, saydamlık, her zaman üstte | ✅ | ✅ (renk) |
| Arka planda çalışma (tepsi) + bildirimler | ✅ | ✅ (uygulama kapalıyken de) |

### Ay Kalkanı nasıl çalışır?
Her adres **açılmadan önce** 15+ sinyalle puanlanır (0–100) ve nedenleri gösterilir:
marka taklidi (garanti, ziraat, e-devlet, paypal…), harf/rakam hilesi (`paypa1`), yazım benzerliği (`gooogle`),
Kiril/Yunan harfli sahte alan adları (`аpple.com`), şüpheli uzantılar (.xyz, .top, .tk…), `@` hilesi, çıplak IP,
kısaltılmış linkler, ücretsiz barındırma, giriş/ödeme kelimeleri. Sayfa yüklendikten sonra da şifre/kart alanları
şüpheli veya şifresiz sayfadaysa uyarır. **Hiçbir veri dışarı gönderilmez** — tamamen cihazda çalışan, açıklanabilir kural tabanlı bir model.
Sıkı modda 45+, dengeli modda 65+ puan alan sayfalar durdurulur.

### Kale gibi mimari (masaüstü)
Her sekme ayrı sandbox'lı süreçte (`sandbox`, `contextIsolation`, Node erişimi yok), arayüz ile ana süreç arasında
beyaz listeli tek bir köprü, IPC'de gönderen doğrulaması, `<webview>` yasak, katı CSP, geçersiz sertifikaya asla izin yok,
gizli oturum diske yazılmaz, veriler atomik olarak kaydedilir.

---

## 🖥️ Masaüstü — çalıştırma ve kurulum dosyası

Gereken: [Node.js 20+](https://nodejs.org)

```bash
cd desktop
npm install
npm start            # geliştirme modunda aç
npm run dist         # Windows kurulum dosyası (dist/MoonBrowser Setup 1.0.0.exe)
npm run dist:mac     # macOS (.dmg) — Mac'te çalıştırın
npm run dist:linux   # Linux (.AppImage)
```

Kısayollar: Ctrl+T yeni sekme · Ctrl+Shift+N gizli · Ctrl+W kapat · Ctrl+L adres · Ctrl+D yer imi ·
Ctrl+J görevler · Ctrl+, ayarlar · Ctrl+Tab sekme değiştir · Ctrl+± yakınlaştır · F11 tam ekran · F12 geliştirici araçları

## 📱 Android — APK oluşturma

Gereken: [Android Studio](https://developer.android.com/studio) (Ladybug veya üstü)

1. Android Studio → **Open** → `android` klasörünü seçin, Gradle senkronizasyonunu bekleyin.
2. Telefonu USB ile bağlayıp ▶ **Run** — ya da **Build → Build APK(s)**.
3. APK: `android/app/build/outputs/apk/debug/app-debug.apk`

Varsayılan tarayıcı yapmak için: Ayarlar → Uygulamalar → Varsayılan uygulamalar → Tarayıcı → MoonBrowser.
Mağazaya yüklemeden önce `app/build.gradle.kts` içindeki imza ayarını kendi anahtarınızla değiştirin.

## Klasör yapısı

```
desktop/
  src/main.js        ana süreç: sekmeler, oturumlar, güvenlik katmanları, görev hatırlatıcıları
  src/shield.js      Ay Kalkanı risk motoru
  src/adblock.js     engelleme listesi + kozmetik filtre
  src/preload.js     arayüz köprüsü (beyaz liste)
  src/pages/         arayüz, yeni sekme, uyarı sayfası, görev penceresi
android/
  app/src/main/java/.../MainActivity.kt   tarayıcı, sekmeler, diyaloglar, görev penceresi
  .../Shield.kt, AdBlock.kt, Store.kt, ReminderReceiver.kt
  app/src/main/assets/                    yeni sekme + uyarı sayfası (masaüstüyle ortak)
```

## Bilinen sınırlar
- Tarayıcı motoru Chromium'dur (Electron / Android WebView); Chrome eklentileri desteklenmez.
- Google hesabı girişi bazen "güvenli olmayan tarayıcı" uyarısı verebilir (gömülü motorlara Google'ın politikası).
- Android'de gizli sekmenin ayrı çerez kasası, WebView'in çoklu profil desteğine bağlıdır (güncel WebView'de var); yoksa uygulama uyarır.
