package net.ayyazilim.moonbrowser

object AdBlock {
    private val HOSTS = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com", "googletagmanager.com",
        "googletagservices.com", "adservice.google.com", "adservice.google.com.tr", "imasdk.googleapis.com",
        "connect.facebook.net", "pixel.facebook.com", "an.facebook.com", "ads.twitter.com", "analytics.twitter.com", "ads.linkedin.com",
        "px.ads.linkedin.com", "analytics.tiktok.com", "ads.tiktok.com", "amazon-adsystem.com", "adnxs.com", "adsrvr.org", "criteo.com",
        "criteo.net", "taboola.com", "outbrain.com", "outbrainimg.com", "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
        "moatads.com", "quantserve.com", "scorecardresearch.com", "hotjar.com", "hotjar.io", "mouseflow.com", "fullstory.com", "crazyegg.com",
        "mc.yandex.ru", "mc.yandex.com", "an.yandex.ru", "yandexadexchange.net", "ads.yahoo.com", "advertising.com", "adform.net",
        "smartadserver.com", "teads.tv", "sharethrough.com", "media.net", "zemanta.com", "mgid.com", "revcontent.com", "propellerads.com",
        "popads.net", "popcash.net", "exoclick.com", "adsterra.com", "onclickads.net", "trafficjunky.net", "juicyads.com", "admatic.com.tr",
        "admaticsupply.com", "reklamstore.com", "reklamaction.com", "adhood.com", "segmentify.com", "insider.com.tr", "useinsider.com",
        "clarity.ms", "bat.bing.com", "branch.io", "app-measurement.com", "appsflyer.com", "adjust.com", "mixpanel.com", "segment.io",
        "segment.com", "amplitude.com", "nr-data.net", "chartbeat.com", "chartbeat.net", "parsely.com",
        "demdex.net", "omtrdc.net", "2o7.net", "everesttech.net", "bluekai.com", "krxd.net", "adsafeprotected.com", "doubleverify.com",
        "serving-sys.com", "flashtalking.com", "yieldmo.com", "gumgum.com", "sonobi.com", "lijit.com", "sovrn.com", "contextweb.com",
        "indexww.com", "33across.com", "bidswitch.net", "smaato.net", "inmobi.com", "unityads.unity3d.com", "coinhive.com", "coin-hive.com",
        "cryptoloot.pro", "webminepool.com"
    )

    fun isAdHost(hostIn: String?): Boolean {
        var host = hostIn?.lowercase() ?: return false
        while (host.contains('.')) {
            if (host in HOSTS) return true
            host = host.substringAfter('.')
        }
        return false
    }

    private const val CSS = "ins.adsbygoogle,.adsbygoogle,[id^=google_ads_],[id^=div-gpt-ad],[data-ad-slot],[data-ad-unit]," +
        "iframe[src*=doubleclick],iframe[src*=googlesyndication],.ad-banner,.ad-container,.ad-wrapper,.ad-slot,.advert," +
        ".advertisement,.sponsored-ad,.sticky-ad,[id^=taboola-],.trc_related_container,.OUTBRAIN,#carbonads,.reklam,.reklam-alani," +
        "[id^=reklam]{display:none!important;height:0!important;min-height:0!important}"

    const val COSMETIC_JS = "(function(){if(document.getElementById('moon-ab'))return;var s=document.createElement('style');" +
        "s.id='moon-ab';s.textContent='$CSS';(document.head||document.documentElement).appendChild(s);})();"

    const val INSPECT_JS = "(function(){var pw=document.querySelectorAll('input[type=password]').length;" +
        "var cc=document.querySelectorAll('input[autocomplete^=\"cc-\"],input[name*=card i],input[name*=cvv i],input[name*=kart i]').length;" +
        "var ins=[].filter.call(document.forms,function(f){return (f.action||'').indexOf('http:')===0}).length;" +
        "return pw+','+cc+','+ins;})()"
}
