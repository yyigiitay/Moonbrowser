package net.ayyazilim.moonbrowser

import android.net.Uri
import java.net.IDN

/**
 * Ay Kalkanı — yerel, açıklanabilir risk analiz motoru (masaüstü sürümüyle aynı kurallar).
 * Hiçbir veri cihaz dışına gönderilmez.
 */
object Shield {
    data class Reason(val pts: Int, val why: String)
    data class Verdict(val score: Int, val level: String, val reasons: List<Reason>)

    val INTERNAL = Verdict(0, "internal", emptyList())

    private val MULTI_SUFFIX = setOf(
        "com.tr", "gov.tr", "org.tr", "net.tr", "edu.tr", "bel.tr", "k12.tr", "av.tr", "gen.tr", "biz.tr", "info.tr", "pol.tr", "tsk.tr",
        "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "co.jp", "com.br", "co.nz", "co.za", "com.cn", "com.mx", "co.in", "com.de"
    )
    private val SUSPICIOUS_TLDS = setOf(
        "zip", "mov", "tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "country", "kim", "work", "rest", "fit", "loan",
        "men", "bid", "win", "review", "date", "racing", "download", "stream", "cam", "icu", "monster", "sbs", "cfd", "buzz", "lol", "quest"
    )
    private val BRANDS = mapOf(
        "paypal" to listOf("paypal.com"), "apple" to listOf("apple.com", "icloud.com"), "icloud" to listOf("icloud.com", "apple.com"),
        "microsoft" to listOf("microsoft.com", "live.com", "office.com", "microsoftonline.com", "outlook.com"),
        "outlook" to listOf("outlook.com", "live.com", "microsoft.com"),
        "google" to listOf("google.com", "google.com.tr", "youtube.com", "gmail.com", "googleusercontent.com", "gstatic.com"),
        "gmail" to listOf("gmail.com", "google.com"), "youtube" to listOf("youtube.com", "youtu.be", "google.com"),
        "facebook" to listOf("facebook.com", "fb.com", "facebook.net"), "instagram" to listOf("instagram.com"),
        "whatsapp" to listOf("whatsapp.com", "whatsapp.net"), "netflix" to listOf("netflix.com"),
        "amazon" to listOf("amazon.com", "amazon.com.tr", "amazonaws.com"),
        "garanti" to listOf("garantibbva.com.tr", "garanti.com.tr"), "ziraat" to listOf("ziraatbank.com.tr", "ziraat.com.tr"),
        "akbank" to listOf("akbank.com", "akbank.com.tr"), "isbank" to listOf("isbank.com.tr"), "yapikredi" to listOf("yapikredi.com.tr"),
        "halkbank" to listOf("halkbank.com.tr"), "vakifbank" to listOf("vakifbank.com.tr"), "denizbank" to listOf("denizbank.com"),
        "enpara" to listOf("enpara.com"), "papara" to listOf("papara.com"), "edevlet" to listOf("turkiye.gov.tr"), "turkiye" to listOf("turkiye.gov.tr"),
        "ptt" to listOf("ptt.gov.tr", "pttavm.com"), "hepsiburada" to listOf("hepsiburada.com"), "trendyol" to listOf("trendyol.com"),
        "sahibinden" to listOf("sahibinden.com"), "binance" to listOf("binance.com", "binance.tr"), "metamask" to listOf("metamask.io"),
        "steam" to listOf("steampowered.com", "steamcommunity.com"), "telegram" to listOf("telegram.org", "t.me"),
        "twitter" to listOf("twitter.com", "x.com"), "linkedin" to listOf("linkedin.com"), "dropbox" to listOf("dropbox.com")
    )
    private val TRUSTED = BRANDS.values.flatten().toSet() + setOf(
        "wikipedia.org", "github.com", "stackoverflow.com", "mozilla.org", "duckduckgo.com", "bing.com", "yandex.com.tr", "yandex.ru",
        "brave.com", "startpage.com", "claude.ai", "anthropic.com", "reddit.com", "cloudflare.com", "androidplatform.net"
    )
    private val SHORTENERS = setOf("bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "ow.ly", "rebrand.ly", "shorturl.at", "tiny.cc", "rb.gy")
    private val FREE_HOSTS = listOf(
        "000webhostapp.com", "firebaseapp.com", "web.app", "glitch.me", "netlify.app", "vercel.app", "pages.dev",
        "ngrok.io", "ngrok-free.app", "trycloudflare.com", "weebly.com", "wixsite.com", "blogspot.com", "repl.co", "herokuapp.com"
    )
    private val HOST_WORDS = listOf(
        "login", "signin", "verify", "secure", "account", "update", "banking", "wallet", "giris", "dogrula", "sifre", "hesap",
        "odeme", "kampanya", "hediye", "odul", "iade", "destek", "support", "confirm", "unlock", "billing"
    )
    private val PATH_WORDS = listOf("login", "signin", "verify", "wp-admin", "webscr", "giris", "dogrulama", "sifre", "odeme", "kart", "card", "cvv")
    private val CONFUSABLE = mapOf(
        'а' to 'a', 'е' to 'e', 'о' to 'o', 'р' to 'p', 'с' to 'c', 'у' to 'y', 'х' to 'x', 'і' to 'i', 'ј' to 'j', 'ѕ' to 's',
        'һ' to 'h', 'ԁ' to 'd', 'ɡ' to 'g', 'ο' to 'o', 'α' to 'a', 'ν' to 'v', 'τ' to 't', 'κ' to 'k', 'ρ' to 'p', 'ι' to 'i',
        'ӏ' to 'l', 'ԛ' to 'q', 'ԝ' to 'w', 'ɩ' to 'l'
    )
    private val IPV4 = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")
    private val LOCAL = Regex("""^(127|10)\.|^192\.168\.|^172\.(1[6-9]|2\d|3[01])\.""")
    private val CYR_GREEK = Regex("[\\u0370-\\u03ff\\u0400-\\u04ff]")

    fun site(host: String): String {
        val l = host.split('.')
        if (l.size <= 2) return host
        val last2 = l.takeLast(2).joinToString(".")
        return if (last2 in MULTI_SUFFIX) l.takeLast(3).joinToString(".") else last2
    }

    fun isLocal(host: String) = host == "localhost" || host.endsWith(".local") || LOCAL.containsMatchIn(host)

    private fun deLeet(s: String) = s.replace('0', 'o').replace('1', 'l').replace('3', 'e').replace('4', 'a')
        .replace('5', 's').replace('7', 't').replace("rn", "m").replace("vv", "w")

    private fun lev(a: String, b: String): Int {
        if (kotlin.math.abs(a.length - b.length) > 1) return 9
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    fun analyze(url: String): Verdict {
        val u = try { Uri.parse(url) } catch (e: Exception) { return Verdict(0, "safe", emptyList()) }
        val scheme = u.scheme?.lowercase() ?: return INTERNAL
        if (scheme != "http" && scheme != "https") return INTERNAL
        val host = (u.host ?: return Verdict(0, "safe", emptyList())).lowercase()
        if (host == "appassets.androidplatform.net") return INTERNAL
        if (isLocal(host)) return Verdict(0, "safe", emptyList())

        val reasons = mutableListOf<Reason>()
        var score = 0
        fun add(p: Int, why: String) { score += p; reasons += Reason(p, why) }

        val s = site(host)
        val puny = host.split('.').any { it.startsWith("xn--") }
        val userInfo = !u.userInfo.isNullOrEmpty()
        if (s in TRUSTED && !puny && !userInfo) {
            if (scheme == "http") add(10, "Şifrelenmemiş bağlantı (HTTP)")
            return finish(score, reasons)
        }
        if (scheme == "http") add(10, "Şifrelenmemiş bağlantı (HTTP)")
        if (IPV4.matches(host) || host.contains(':')) add(30, "Alan adı yerine çıplak IP adresi kullanılıyor")

        var uni = host
        if (puny) {
            uni = try { IDN.toUnicode(host) } catch (e: Exception) { host }
            val mixed = Regex("[a-z]").containsMatchIn(uni) && CYR_GREEK.containsMatchIn(uni)
            if (mixed) add(45, "Karışık alfabe hilesi: \"$uni\" Latin harf gibi görünen Kiril/Yunan harfler içeriyor")
            else add(25, "Uluslararası karakterli alan adı (punycode)")
        }
        if (userInfo) add(30, "Adreste \"@\" hilesi — gerçek hedef gizleniyor")
        if (u.port != -1 && u.port != 80 && u.port != 443) add(10, "Alışılmadık port (${u.port})")

        val sub = if (host.length > s.length) host.dropLast(s.length + 1) else ""
        if (sub.isNotEmpty() && sub.split('.').size >= 3) add(15, "Çok fazla alt alan adı katmanı")
        if (host.replace("xn--", "").count { it == '-' } >= 3) add(12, "Alan adında aşırı tire kullanımı")
        val tld = host.substringAfterLast('.')
        if (tld in SUSPICIOUS_TLDS) add(18, "Dolandırıcılıkta sık görülen uzantı (.$tld)")
        if (host.length > 40) add(8, "Olağandışı uzun alan adı")
        if (url.length > 220) add(5, "Olağandışı uzun adres")
        if (host in SHORTENERS) add(10, "Kısaltılmış bağlantı — gerçek hedef gizli")
        if (FREE_HOSTS.any { host == it || host.endsWith(".$it") }) add(10, "Ücretsiz barındırma servisi (oltalama sitelerinde yaygın)")

        val hw = HOST_WORDS.filter { host.contains(it) }
        if (hw.isNotEmpty()) add(minOf(20, hw.size * 10), "Alan adında güven sömürüsü kelimeler: ${hw.joinToString(", ")}")
        val path = ((u.encodedPath ?: "") + "?" + (u.encodedQuery ?: "")).lowercase()
        val pw = PATH_WORDS.filter { path.contains(it) }
        if (pw.isNotEmpty()) add(minOf(10, pw.size * 5), "Adres yolunda giriş/ödeme kelimeleri")

        val flat = uni.map { CONFUSABLE[it] ?: it }.joinToString("").replace(".", "").replace("-", "")
        val leet = deLeet(flat)
        val label = s.substringBefore('.')
        for ((brand, official) in BRANDS) {
            if (s in official) continue
            if (flat.contains(brand)) { add(45, "\"$brand\" markasını taklit ediyor olabilir (resmi alan adı değil)"); break }
            if (leet.contains(brand)) { add(55, "\"$brand\" adının harf/rakam hilesiyle yazılmış hali"); break }
            if (brand.length >= 5 && lev(label, brand) == 1) { add(50, "\"$brand\" adına çok benzeyen yazım (typosquatting)"); break }
        }
        return finish(score, reasons)
    }

    private fun finish(raw: Int, reasons: List<Reason>): Verdict {
        val s = minOf(100, raw)
        return Verdict(s, if (s >= 65) "danger" else if (s >= 30) "caution" else "safe", reasons)
    }
}
