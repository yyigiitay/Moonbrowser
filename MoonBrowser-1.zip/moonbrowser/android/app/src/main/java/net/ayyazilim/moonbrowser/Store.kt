package net.ayyazilim.moonbrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val title: String, val url: String)
data class HistoryItem(val title: String, val url: String, val t: Long)
data class Task(
    val id: String, var title: String, var due: Long?, var priority: String, var cat: String,
    var repeat: String, var done: Boolean, var notified: Boolean
)

/** SharedPreferences üzerinde basit JSON deposu. Yedeklemeye kapalıdır (manifest). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("moon", Context.MODE_PRIVATE)

    var adblock: Boolean get() = p.getBoolean("adblock", true); set(v) = p.edit().putBoolean("adblock", v).apply()
    var httpsOnly: Boolean get() = p.getBoolean("httpsOnly", true); set(v) = p.edit().putBoolean("httpsOnly", v).apply()
    var thirdPartyCookies: Boolean get() = p.getBoolean("tpc", false); set(v) = p.edit().putBoolean("tpc", v).apply()
    var shield: String get() = p.getString("shield", "strict")!!; set(v) = p.edit().putString("shield", v).apply()
    var engine: String get() = p.getString("engine", "duckduckgo")!!; set(v) = p.edit().putString("engine", v).apply()
    var background: String get() = p.getString("bg", "auto")!!; set(v) = p.edit().putString("bg", v).apply()
    var taskAccent: Int get() = p.getInt("taskAccent", 0xFFA99CFF.toInt()); set(v) = p.edit().putInt("taskAccent", v).apply()
    var blockedTotal: Long get() = p.getLong("blocked", 0); set(v) = p.edit().putLong("blocked", v).apply()
    var threats: Long get() = p.getLong("threats", 0); set(v) = p.edit().putLong("threats", v).apply()

    val threshold get() = when (shield) { "strict" -> 45; "balanced" -> 65; else -> 999 }

    var bookmarks: List<Bookmark>
        get() = arr("bookmarks", """[{"t":"Wikipedia","u":"https://tr.wikipedia.org/"},{"t":"GitHub","u":"https://github.com/"},{"t":"Claude","u":"https://claude.ai/"}]""")
            .map { Bookmark(it.optString("t"), it.optString("u")) }
        set(v) = put("bookmarks", v.map { JSONObject().put("t", it.title).put("u", it.url) })

    var history: List<HistoryItem>
        get() = arr("history", "[]").map { HistoryItem(it.optString("t"), it.optString("u"), it.optLong("d")) }
        set(v) = put("history", v.take(1500).map { JSONObject().put("t", it.title).put("u", it.url).put("d", it.t) })

    fun addHistory(title: String, url: String) {
        val h = history.toMutableList()
        if (h.firstOrNull()?.url == url) h.removeAt(0)
        h.add(0, HistoryItem(title.ifBlank { url }, url, System.currentTimeMillis()))
        history = h
    }

    var tasks: List<Task>
        get() = arr("tasks", "[]").map {
            Task(it.optString("id"), it.optString("title"), if (it.has("due") && !it.isNull("due")) it.getLong("due") else null,
                it.optString("pri", "mid"), it.optString("cat"), it.optString("rep", "none"), it.optBoolean("done"), it.optBoolean("notified"))
        }
        set(v) = put("tasks", v.map {
            JSONObject().put("id", it.id).put("title", it.title).put("due", it.due ?: JSONObject.NULL).put("pri", it.priority)
                .put("cat", it.cat).put("rep", it.repeat).put("done", it.done).put("notified", it.notified)
        })

    private fun arr(key: String, def: String): List<JSONObject> = try {
        val a = JSONArray(p.getString(key, def)); (0 until a.length()).map { a.getJSONObject(it) }
    } catch (e: Exception) { emptyList() }

    private fun put(key: String, list: List<JSONObject>) {
        val a = JSONArray(); list.forEach { a.put(it) }
        p.edit().putString(key, a.toString()).apply()
    }
}
