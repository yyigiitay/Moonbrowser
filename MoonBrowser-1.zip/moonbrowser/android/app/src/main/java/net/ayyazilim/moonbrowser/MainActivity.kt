package net.ayyazilim.moonbrowser

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.DownloadManager
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.*

class Tab(val web: WebView, val private: Boolean) {
    var blocked = 0
    var verdict = Shield.INTERNAL
    var pageWarn = ""
    val bypass = mutableSetOf<String>()
}

class MainActivity : AppCompatActivity() {

    // ── renkler ──
    private val BG = Color.parseColor("#0B0D1A")
    private val BG2 = Color.parseColor("#12152A")
    private val BG3 = Color.parseColor("#1A1E38")
    private val LINE = Color.parseColor("#262A4A")
    private val TEXT = Color.parseColor("#E8E6FF")
    private val DIM = Color.parseColor("#8F8CB8")
    private val ACCENT = Color.parseColor("#A99CFF")
    private val SAFE = Color.parseColor("#6EE7B7")
    private val CAUTION = Color.parseColor("#FBBF24")
    private val DANGER = Color.parseColor("#FB7185")
    private val PRIV = Color.parseColor("#C084FC")

    private val ASSETS = "https://appassets.androidplatform.net/assets/"
    private val PRIVATE_PROFILE = "moon-private"
    private val ENGINES = mapOf(
        "duckduckgo" to "https://duckduckgo.com/?q=", "brave" to "https://search.brave.com/search?q=",
        "startpage" to "https://www.startpage.com/do/search?q=", "google" to "https://www.google.com/search?q=",
        "bing" to "https://www.bing.com/search?q=", "yandex" to "https://yandex.com.tr/search/?text="
    )
    private val DANGEROUS_EXT = Regex("""\.(apk|xapk|apks|exe|msi|bat|cmd|scr|vbs|js|jar|ps1|hta|sh|dmg|pkg|docm|xlsm)$""", RegexOption.IGNORE_CASE)

    private lateinit var store: Store
    private lateinit var root: LinearLayout
    private lateinit var container: FrameLayout
    private lateinit var address: EditText
    private lateinit var shieldBtn: TextView
    private lateinit var tabCount: TextView
    private lateinit var progress: ProgressBar
    private lateinit var backBtn: TextView
    private lateinit var fwdBtn: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout

    private val tabs = mutableListOf<Tab>()
    private var current: Tab? = null
    private val httpExceptions = mutableSetOf<String>()
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermission: PermissionRequest? = null
    private var pendingGeo: Pair<String, GeolocationPermissions.Callback>? = null

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
    }
    private val multiProfile by lazy { WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE) }

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        pendingPermission?.let { req ->
            val ok = res.values.all { it }
            if (ok) req.grant(req.resources) else req.deny()
            pendingPermission = null
        }
        pendingGeo?.let { (origin, cb) ->
            cb.invoke(origin, res.values.any { it }, false)
            pendingGeo = null
        }
    }

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
    private fun round(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }

    // ═══════════════════════════ Yaşam döngüsü ═══════════════════════════
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        buildUi()
        ReminderReceiver.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }
        handleIntent(intent, first = true)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val t = current
                when {
                    customView != null -> hideCustomView()
                    address.hasFocus() -> { address.clearFocus(); hideKeyboard() }
                    t != null && t.web.canGoBack() -> t.web.goBack()
                    t != null && tabs.size > 1 -> closeTab(t)
                    else -> moveTaskToBack(true)
                }
            }
        })
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent, first = false) }

    private fun handleIntent(i: Intent?, first: Boolean) {
        val url = when (i?.action) {
            Intent.ACTION_VIEW -> i.dataString
            Intent.ACTION_WEB_SEARCH -> i.getStringExtra("query")?.let { resolve(it) }
            else -> null
        }
        if (url != null) newTab(url) else if (first || tabs.isEmpty()) newTab(null)
        if (i?.getBooleanExtra("openTasks", false) == true) showTasks()
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    override fun onDestroy() {
        tabs.forEach { (it.web.parent as? ViewGroup)?.removeView(it.web); it.web.destroy() }
        tabs.clear()
        wipePrivate()
        super.onDestroy()
    }

    // ═══════════════════════════ Arayüz ═══════════════════════════
    @SuppressLint("SetTextI18n")
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(BG)
        }
        shieldBtn = TextView(this).apply {
            textSize = 12f; setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0); height = dp(32); minimumHeight = dp(32)
            setOnClickListener { showShield() }
        }
        address = EditText(this).apply {
            setSingleLine(); textSize = 15f; setTextColor(TEXT); setHintTextColor(Color.parseColor("#6A678F"))
            hint = "Ara veya adres yaz…"; background = null; setPadding(dp(8), 0, dp(8), 0)
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setOnEditorActionListener { _, id, ev ->
                if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                    current?.let { load(it, text.toString()) }; clearFocus(); hideKeyboard(); true
                } else false
            }
            setOnFocusChangeListener { _, f -> if (f) post { selectAll() } else refreshChrome() }
        }
        val omni = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = round(BG2, 22, LINE); setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(shieldBtn); addView(address, LinearLayout.LayoutParams(0, dp(36), 1f))
        }
        tabCount = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 12f; setTextColor(TEXT); setTypeface(typeface, Typeface.BOLD)
            background = round(Color.TRANSPARENT, 7, DIM)
            setOnClickListener { showTabs() }
            setOnLongClickListener { newTab(null, private = true); true }
        }
        topBar.addView(omni, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topBar.addView(tabCount, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginStart = dp(12); marginEnd = dp(4) })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(ACCENT); progressBackgroundTintList = ColorStateList.valueOf(BG)
        }
        container = FrameLayout(this).apply { setBackgroundColor(BG) }

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(BG2); gravity = Gravity.CENTER_VERTICAL
        }
        fun barBtn(glyph: String, desc: String, click: () -> Unit) = TextView(this).apply {
            text = glyph; textSize = 21f; gravity = Gravity.CENTER; setTextColor(TEXT); contentDescription = desc
            setOnClickListener { click() }
            val tv = TypedValue(); context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
        }.also { bottomBar.addView(it, LinearLayout.LayoutParams(0, dp(52), 1f)) }
        backBtn = barBtn("‹", "Geri") { current?.web?.goBack() }
        fwdBtn = barBtn("›", "İleri") { current?.web?.goForward() }
        barBtn("☾", "Ana sayfa") { current?.let { load(it, "moon://newtab") } }
        barBtn("☑", "Görevler") { showTasks() }
        val menuBtn = barBtn("⋮", "Menü") {}
        menuBtn.setOnClickListener { showMenu(menuBtn) }

        root.addView(topBar)
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)))
        root.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottomBar)
        setContentView(root)
    }

    private fun hideKeyboard() = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0)
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    @SuppressLint("SetTextI18n")
    private fun refreshChrome() {
        val t = current ?: return
        tabCount.text = tabs.size.toString()
        tabCount.background = round(if (t.private) Color.parseColor("#2A1650") else Color.TRANSPARENT, 7, if (t.private) PRIV else DIM)
        if (!address.hasFocus()) address.setText(displayUrl(t))
        address.hint = if (t.private) "Gizli arama — kaydedilmez" else "Ara veya adres yaz…"
        val (col, label) = when (t.verdict.level) {
            "safe" -> SAFE to (if (t.web.url?.startsWith("https") == true) "🔒" else "🛡")
            "caution" -> CAUTION to "⚠"
            "danger" -> DANGER to "⛔"
            else -> ACCENT to "☾"
        }
        shieldBtn.text = if (t.blocked > 0) "$label ${t.blocked}" else label
        shieldBtn.setTextColor(col)
        shieldBtn.background = round(Color.argb(36, Color.red(col), Color.green(col), Color.blue(col)), 16)
        backBtn.alpha = if (t.web.canGoBack()) 1f else .3f
        fwdBtn.alpha = if (t.web.canGoForward()) 1f else .3f
        topBar.setBackgroundColor(if (t.private) Color.parseColor("#160F2A") else BG)
    }

    private fun displayUrl(t: Tab): String {
        val u = t.web.url ?: return ""
        if (u.startsWith(ASSETS + "newtab")) return ""
        if (u.startsWith(ASSETS + "guard")) return Uri.parse(u).getQueryParameter("url") ?: ""
        return u
    }

    // ═══════════════════════════ Sekmeler ═══════════════════════════
    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String?, private: Boolean = false, background: Boolean = false): Tab {
        val web = WebView(this)
        if (private && multiProfile) {
            ProfileStore.getInstance().getOrCreateProfile(PRIVATE_PROFILE)
            WebViewCompat.setProfile(web, PRIVATE_PROFILE)
        }
        web.setBackgroundColor(BG)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = false
            builtInZoomControls = true; displayZoomControls = false
            loadWithOverviewMode = true; useWideViewPort = true
            mediaPlaybackRequiresUserGesture = true
            setGeolocationEnabled(true)
            userAgentString = userAgentString.replace("; wv", "").replace(Regex(" Version/\\d+\\.\\d+"), "")
            if (private) cacheMode = WebSettings.LOAD_NO_CACHE
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) WebSettingsCompat.setSafeBrowsingEnabled(web.settings, true)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, false)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, store.thirdPartyCookies)

        val tab = Tab(web, private)
        web.webViewClient = MoonClient(tab)
        web.webChromeClient = MoonChrome(tab)
        web.setDownloadListener { u, ua, cd, mime, _ -> download(tab, u, ua, cd, mime) }
        web.setOnLongClickListener { longPress(tab) }

        tabs += tab
        if (private && !multiProfile) toast("Bu cihazın WebView sürümü ayrı gizli profili desteklemiyor: geçmiş/önbellek tutulmaz ama çerezler ortaktır.")
        if (!background || current == null) switchTo(tab)
        load(tab, url ?: "moon://newtab")
        refreshChrome()
        return tab
    }

    private fun switchTo(t: Tab) {
        current?.web?.let { container.removeView(it); it.onPause() }
        current = t
        if (t.web.parent == null) container.addView(t.web, FrameLayout.LayoutParams(-1, -1))
        t.web.onResume()
        refreshChrome()
    }

    private fun closeTab(t: Tab) {
        val idx = tabs.indexOf(t)
        tabs.remove(t)
        container.removeView(t.web)
        t.web.stopLoading(); t.web.destroy()
        if (t.private && tabs.none { it.private }) wipePrivate()
        if (tabs.isEmpty()) { current = null; newTab(null); return }
        if (current == t) { current = null; switchTo(tabs[minOf(idx, tabs.size - 1)]) }
        refreshChrome()
    }

    private fun wipePrivate() {
        if (!multiProfile) return
        try { ProfileStore.getInstance().deleteProfile(PRIVATE_PROFILE); toast("Gizli oturum verileri silindi 🌑") } catch (_: Exception) { }
    }

    // ═══════════════════════════ Gezinme & Kalkan ═══════════════════════════
    private fun resolve(input: String): String {
        val s = input.trim()
        if (s.isEmpty() || s == "moon://newtab") return "moon://newtab"
        if (s.startsWith("http://", true) || s.startsWith("https://", true)) return s
        if (!s.contains(' ') && Regex("""^[\w-]+(\.[\w-]+)+(:\d+)?(/.*)?$""").matches(s)) return "https://$s"
        if (!s.contains(' ') && s.startsWith("localhost")) return "http://$s"
        return (ENGINES[store.engine] ?: ENGINES.getValue("duckduckgo")) + Uri.encode(s)
    }

    private fun newtabUrl(t: Tab): String {
        val bm = JSONArray()
        store.bookmarks.take(8).forEach { bm.put(JSONObject().put("t", it.title).put("u", it.url)) }
        return Uri.parse(ASSETS + "newtab.html").buildUpon()
            .appendQueryParameter("bg", store.background).appendQueryParameter("interval", "25")
            .appendQueryParameter("engine", store.engine).appendQueryParameter("priv", if (t.private) "1" else "0")
            .appendQueryParameter("bm", bm.toString()).build().toString()
    }

    fun load(t: Tab, input: String) {
        val url = resolve(input)
        if (url.startsWith("moon://")) { t.web.loadUrl(newtabUrl(t)); return }
        val v = verdictFor(t, url)
        if (v.score >= store.threshold) { showThreat(t, url, v); return }
        t.web.loadUrl(upgrade(url))
    }

    private fun verdictFor(t: Tab, url: String): Shield.Verdict {
        val host = Uri.parse(url).host ?: ""
        return if (host in t.bypass) Shield.Verdict(0, "caution", listOf(Shield.Reason(0, "Kalkan uyarısı sizin tarafınızdan geçildi"))) else Shield.analyze(url)
    }

    private fun upgrade(url: String): String {
        val u = Uri.parse(url)
        val host = u.host ?: return url
        return if (store.httpsOnly && u.scheme == "http" && !Shield.isLocal(host) && host !in httpExceptions)
            u.buildUpon().scheme("https").build().toString() else url
    }

    private fun showThreat(t: Tab, url: String, v: Shield.Verdict) {
        store.threats = store.threats + 1
        val reasons = JSONArray(); v.reasons.forEach { reasons.put(it.why) }
        t.web.loadUrl(Uri.parse(ASSETS + "guard.html").buildUpon().appendQueryParameter("mode", "threat")
            .appendQueryParameter("url", url).appendQueryParameter("score", v.score.toString())
            .appendQueryParameter("reasons", reasons.toString()).build().toString())
        toast("Ay Kalkanı tehlikeli bir sayfayı durdurdu")
    }

    private fun showError(t: Tab, url: String, desc: String) {
        t.web.loadUrl(Uri.parse(ASSETS + "guard.html").buildUpon().appendQueryParameter("mode", "error")
            .appendQueryParameter("url", url).appendQueryParameter("desc", desc)
            .appendQueryParameter("https", if (store.httpsOnly) "1" else "0").build().toString())
    }

    /** true = gezinmeyi biz devraldık */
    private fun intercept(t: Tab, url: String): Boolean {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase() ?: return true
        if (scheme != "http" && scheme != "https") { openExternal(url); return true }
        if (uri.host == "appassets.androidplatform.net") return false
        val cur = t.web.url ?: ""
        if (cur.startsWith(ASSETS + "guard")) {
            val mode = Uri.parse(cur).getQueryParameter("mode")
            if (mode == "threat") t.bypass += (uri.host ?: "")
            if (scheme == "http") httpExceptions += (uri.host ?: "")
            return false
        }
        val v = verdictFor(t, url)
        if (v.score >= store.threshold) { showThreat(t, url, v); return true }
        val up = upgrade(url)
        if (up != url) { t.web.loadUrl(up); return true }
        return false
    }

    private fun openExternal(url: String) {
        val intent = try {
            if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                addCategory(Intent.CATEGORY_BROWSABLE); component = null; selector = null
            } else Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)
        } catch (e: Exception) { return }
        AlertDialog.Builder(this).setTitle("Harici uygulama")
            .setMessage("Bu bağlantı tarayıcı dışında bir uygulama açmak istiyor:\n\n${url.take(140)}")
            .setNegativeButton("İptal", null)
            .setPositiveButton("Aç") { _, _ ->
                try { startActivity(intent) } catch (e: ActivityNotFoundException) {
                    val fallback = intent.getStringExtra("browser_fallback_url")
                    if (fallback != null && fallback.startsWith("https")) current?.let { load(it, fallback) } else toast("Bunu açacak uygulama yok")
                }
            }.show()
    }

    private inner class MoonClient(val tab: Tab) : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
            val u = req.url
            if (u.host == "appassets.androidplatform.net") return assetLoader.shouldInterceptRequest(u)
            if (store.adblock && !req.isForMainFrame && AdBlock.isAdHost(u.host)) {
                runOnUiThread { tab.blocked++; store.blockedTotal = store.blockedTotal + 1; if (tab == current) refreshChrome() }
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
            if (!request.isForMainFrame) false else intercept(tab, request.url.toString())

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            tab.blocked = 0; tab.pageWarn = ""
            // güvenlik ağı: yönlendirme veya pencere açma ile gelen adresler de denetlenir
            if (url.startsWith("http") && !url.startsWith(ASSETS)) {
                val v = verdictFor(tab, url)
                if (v.score >= store.threshold) { view.stopLoading(); showThreat(tab, url, v); return }
                tab.verdict = v
            } else tab.verdict = Shield.INTERNAL
            if (tab == current) refreshChrome()
        }

        override fun onPageFinished(view: WebView, url: String) {
            if (tab == current) refreshChrome()
            if (!url.startsWith("http") || url.startsWith(ASSETS)) return
            if (store.adblock) view.evaluateJavascript(AdBlock.COSMETIC_JS, null)
            if (!tab.private) store.addHistory(view.title ?: url, url)
            view.evaluateJavascript(AdBlock.INSPECT_JS) { r ->
                val p = r.trim('"').split(',').mapNotNull { it.toIntOrNull() }
                if (p.size < 3) return@evaluateJavascript
                val warn = mutableListOf<String>()
                if ((p[0] > 0 || p[1] > 0) && url.startsWith("http:")) warn += "Şifre/kart alanı şifrelenmemiş sayfada!"
                if (p[2] > 0) warn += "Form verileri şifrelenmeden gönderiliyor"
                if ((p[0] > 0 || p[1] > 0) && tab.verdict.level != "safe") warn += "Şüpheli adreste şifre/kart bilgisi isteniyor — DİKKAT"
                if (warn.isNotEmpty()) {
                    tab.pageWarn = warn.joinToString(" · ")
                    tab.verdict = tab.verdict.copy(level = if (tab.verdict.level == "safe") "caution" else "danger",
                        reasons = tab.verdict.reasons + warn.map { Shield.Reason(0, it) })
                    toast(warn.first())
                    if (tab == current) refreshChrome()
                }
            }
        }

        override fun onReceivedError(view: WebView, req: WebResourceRequest, err: WebResourceError) {
            if (!req.isForMainFrame) return
            val desc = err.description?.toString()?.removePrefix("net::") ?: "ERR_FAILED"
            if (desc == "ERR_ABORTED") return
            showError(tab, req.url.toString(), desc)
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
            handler.cancel() // geçersiz sertifikaya asla izin verilmez
            val desc = when (error.primaryError) {
                SslError.SSL_EXPIRED, SslError.SSL_NOTYETVALID, SslError.SSL_DATE_INVALID -> "ERR_CERT_DATE_INVALID"
                SslError.SSL_IDMISMATCH -> "ERR_CERT_COMMON_NAME_INVALID"
                else -> "ERR_CERT_AUTHORITY_INVALID"
            }
            showError(tab, error.url, desc)
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            val last = displayUrl(tab)
            val idx = tabs.indexOf(tab)
            container.removeView(view); view.destroy(); tabs.remove(tab)
            val fresh = newTab(null, tab.private)
            if (idx >= 0) { tabs.remove(fresh); tabs.add(minOf(idx, tabs.size), fresh) }
            fresh.web.loadUrl(Uri.parse(ASSETS + "guard.html").buildUpon().appendQueryParameter("mode", "crash")
                .appendQueryParameter("url", last).appendQueryParameter("desc", if (detail.didCrash()) "çökme" else "bellek").build().toString())
            return true
        }
    }

    private inner class MoonChrome(val tab: Tab) : WebChromeClient() {
        override fun onProgressChanged(view: WebView, p: Int) {
            if (tab != current) return
            progress.progress = p
            progress.visibility = if (p in 1..99) View.VISIBLE else View.INVISIBLE
        }

        override fun onReceivedTitle(view: WebView, title: String?) { if (tab == current) refreshChrome() }

        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            if (!isUserGesture) { toast("Açılır pencere engellendi"); return false }
            val nt = newTab(null, tab.private)
            nt.web.stopLoading()
            (resultMsg.obj as WebView.WebViewTransport).webView = nt.web
            resultMsg.sendToTarget()
            return true
        }

        override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
                val wants = request.resources.mapNotNull {
                    when (it) {
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "kamera"
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "mikrofon"
                        else -> null
                    }
                }
                if (wants.isEmpty()) { request.deny(); return@runOnUiThread }
                AlertDialog.Builder(this@MainActivity).setTitle("İzin isteği")
                    .setMessage("${request.origin.host} sitesi ${wants.joinToString(" ve ")} erişimi istiyor.")
                    .setNegativeButton("Reddet") { _, _ -> request.deny() }
                    .setPositiveButton("İzin ver") { _, _ ->
                        val perms = mutableListOf<String>()
                        if ("kamera" in wants) perms += Manifest.permission.CAMERA
                        if ("mikrofon" in wants) perms += Manifest.permission.RECORD_AUDIO
                        pendingPermission = request
                        permLauncher.launch(perms.toTypedArray())
                    }
                    .setOnCancelListener { request.deny() }.show()
            }
        }

        override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
            AlertDialog.Builder(this@MainActivity).setTitle("Konum isteği")
                .setMessage("${Uri.parse(origin).host ?: origin} konumunuzu istiyor." + if (tab.private) "\nGizli sekmede karar kaydedilmez." else "")
                .setNegativeButton("Reddet") { _, _ -> callback.invoke(origin, false, false) }
                .setPositiveButton("İzin ver") { _, _ ->
                    pendingGeo = origin to callback
                    permLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                }
                .setOnCancelListener { callback.invoke(origin, false, false) }.show()
        }

        override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = cb
            return try { filePicker.launch(params.createIntent()); true } catch (e: Exception) { fileCallback = null; false }
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) { callback.onCustomViewHidden(); return }
            customView = view; customCallback = callback
            (window.decorView as FrameLayout).addView(view, FrameLayout.LayoutParams(-1, -1))
            root.visibility = View.GONE
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }

        override fun onHideCustomView() = hideCustomView()
    }

    private fun hideCustomView() {
        val v = customView ?: return
        (window.decorView as FrameLayout).removeView(v)
        customView = null
        root.visibility = View.VISIBLE
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        customCallback?.onCustomViewHidden(); customCallback = null
    }

    private fun longPress(tab: Tab): Boolean {
        val hit = tab.web.hitTestResult
        val link = hit.extra ?: return false
        if (hit.type != WebView.HitTestResult.SRC_ANCHOR_TYPE && hit.type != WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE &&
            hit.type != WebView.HitTestResult.IMAGE_TYPE) return false
        val isImg = hit.type == WebView.HitTestResult.IMAGE_TYPE
        val items = if (isImg) arrayOf("Resmi yeni sekmede aç", "Resmi indir", "Adresi kopyala")
        else arrayOf("Yeni sekmede aç", "Gizli sekmede aç", "Bağlantıyı kopyala", "Ay Kalkanı ile incele")
        AlertDialog.Builder(this).setTitle(link.take(80)).setItems(items) { _, w ->
            when (items[w]) {
                "Yeni sekmede aç", "Resmi yeni sekmede aç" -> { newTab(link, tab.private, background = true); toast("Arka planda açıldı") }
                "Gizli sekmede aç" -> newTab(link, private = true)
                "Bağlantıyı kopyala", "Adresi kopyala" -> {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                        .setPrimaryClip(android.content.ClipData.newPlainText("url", link)); toast("Kopyalandı")
                }
                "Resmi indir" -> download(tab, link, tab.web.settings.userAgentString, null, null)
                "Ay Kalkanı ile incele" -> explain(link)
            }
        }.show()
        return true
    }

    private fun download(tab: Tab, url: String, ua: String, cd: String?, mime: String?) {
        if (!url.startsWith("http")) { toast("Bu dosya türü indirilemiyor"); return }
        val name = URLUtil.guessFileName(url, cd, mime)
        val risk = Shield.analyze(url)
        val go = {
            val req = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mime); addRequestHeader("User-Agent", ua)
                if (!tab.private) CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                setTitle(name); setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            }
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("İndiriliyor: $name")
        }
        if (DANGEROUS_EXT.containsMatchIn(name) || risk.level != "safe") {
            AlertDialog.Builder(this).setTitle("⚠ Ay Kalkanı — riskli indirme")
                .setMessage("\"$name\" cihazınıza uygulama kurabilecek veya riskli bir dosya." +
                    (if (name.endsWith(".apk", true)) "\n\nAPK dosyaları Play Store dışından gelen uygulamalardır; dolandırıcılar bunları sıkça kullanır." else "") +
                    (if (risk.reasons.isNotEmpty()) "\n\nAdres riskleri:\n• " + risk.reasons.joinToString("\n• ") { it.why } else ""))
                .setNegativeButton("İptal", null)
                .setPositiveButton("Riski anlıyorum, indir") { _, _ -> go() }.show()
        } else go()
    }

    // ═══════════════════════════ Diyaloglar ═══════════════════════════
    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val items = listOf("Yeni sekme", "Yeni gizli sekme", "Yer imi ekle/kaldır", "Yer imleri", "Geçmiş", "Görevler", "Ay Kalkanı", "Yenile", "Ayarlar")
        items.forEachIndexed { i, s -> pm.menu.add(0, i, i, s) }
        pm.setOnMenuItemClickListener {
            when (items[it.itemId]) {
                "Yeni sekme" -> newTab(null)
                "Yeni gizli sekme" -> newTab(null, private = true)
                "Yer imi ekle/kaldır" -> toggleBookmark()
                "Yer imleri" -> showBookmarks()
                "Geçmiş" -> showHistory()
                "Görevler" -> showTasks()
                "Ay Kalkanı" -> showShield()
                "Yenile" -> current?.web?.reload()
                "Ayarlar" -> showSettings()
            }
            true
        }
        pm.show()
    }

    private fun sheet(title: String): Pair<LinearLayout, AlertDialog.Builder> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val scroll = ScrollView(this).apply { addView(box) }
        return box to AlertDialog.Builder(this).setTitle(title).setView(scroll)
    }

    private fun label(text: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun switchRow(box: LinearLayout, title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title).apply { setPadding(0, 0, 0, 0) })
        if (sub.isNotEmpty()) texts.addView(label(sub, 12f, DIM).apply { setPadding(0, dp(2), 0, 0) })
        val sw = Switch(this).apply {
            isChecked = value; setOnCheckedChangeListener { _, b -> onChange(b) }
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(ACCENT, DIM))
        }
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(sw)
        box.addView(row)
    }

    private fun showTabs() {
        val (box, b) = sheet("Sekmeler (${tabs.size})")
        lateinit var dlg: AlertDialog
        tabs.forEach { t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(6), dp(10))
                background = round(if (t == current) BG3 else Color.TRANSPARENT, 12, if (t.private) PRIV else null)
                setOnClickListener { switchTo(t); dlg.dismiss() }
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(label((if (t.private) "🕶 " else "") + (t.web.title?.takeIf { it.isNotBlank() && !it.startsWith("Yeni") } ?: if (t.private) "Gizli Sekme" else "Yeni Sekme"), 14f).apply {
                setPadding(0, 0, 0, 0); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            texts.addView(label(displayUrl(t).ifEmpty { "☾ Ana sayfa" }, 12f, DIM).apply { setPadding(0, 0, 0, 0); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            val x = TextView(this).apply {
                text = "✕"; textSize = 16f; setTextColor(DIM); setPadding(dp(14), dp(4), dp(10), dp(4))
                setOnClickListener { closeTab(t); dlg.dismiss(); if (tabs.size > 1) showTabs() }
            }
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(x)
            box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
        dlg = b.setPositiveButton("+ Yeni") { _, _ -> newTab(null) }
            .setNeutralButton("🕶 Gizli") { _, _ -> newTab(null, private = true) }
            .setNegativeButton("Kapat", null).create()
        dlg.show()
    }

    private fun showShield() {
        val t = current ?: return
        val v = t.verdict
        val (box, b) = sheet("Ay Kalkanı")
        val (col, title) = when (v.level) {
            "safe" -> SAFE to "✅ Tehdit tespit edilmedi"
            "caution" -> CAUTION to "⚠ Dikkatli olun"
            "danger" -> DANGER to "⛔ Tehlikeli sayfa"
            else -> ACCENT to "☾ MoonBrowser iç sayfası"
        }
        box.addView(label(title, 17f, col, true))
        val host = Uri.parse(displayUrl(t)).host
        if (host != null) box.addView(label(host, 13f, DIM))
        if (v.level != "internal") {
            box.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; progress = maxOf(3, v.score); progressTintList = ColorStateList.valueOf(col)
            })
            box.addView(label("Risk puanı ${v.score}/100", 12f, DIM))
        }
        v.reasons.forEach { box.addView(label("• ${it.why}" + if (it.pts > 0) "  (+${it.pts})" else "", 13f)) }
        box.addView(label("İSTATİSTİK", 11f, DIM, true).apply { setPadding(0, dp(14), 0, 0) })
        box.addView(label("Bu sayfada engellenen: ${t.blocked}\nToplam engellenen reklam/izleyici: ${store.blockedTotal}\nDurdurulan tehdit: ${store.threats}", 13f))
        box.addView(label("KORUMALAR", 11f, DIM, true).apply { setPadding(0, dp(14), 0, 0) })
        box.addView(label("✓ Google Safe Browsing (zararlı yazılım veritabanı)\n✓ Yerel Ay Kalkanı risk motoru\n✓ Geçersiz sertifikalar her zaman engellenir\n✓ Dosya erişimi kapalı, karışık içerik yasak\n✓ Açılır pencereler yalnızca dokunuşla", 13f, SAFE))
        b.setPositiveButton("Tamam", null).setNeutralButton("Ayarlar") { _, _ -> showSettings() }.show()
    }

    private fun explain(url: String) {
        val v = Shield.analyze(url)
        AlertDialog.Builder(this).setTitle(when (v.level) { "safe" -> "✅ Güvenli görünüyor"; "caution" -> "⚠ Dikkat"; "danger" -> "⛔ Tehlikeli"; else -> "İç sayfa" } + " — ${v.score}/100")
            .setMessage(url.take(200) + "\n\n" + if (v.reasons.isEmpty()) "Risk sinyali bulunamadı." else v.reasons.joinToString("\n") { "• ${it.why} (+${it.pts})" })
            .setPositiveButton("Tamam", null).show()
    }

    private fun toggleBookmark() {
        val t = current ?: return
        val url = t.web.url ?: return
        if (!url.startsWith("http") || url.startsWith(ASSETS)) { toast("Bu sayfa yer imine eklenemez"); return }
        val list = store.bookmarks.toMutableList()
        if (list.removeAll { it.url == url }) toast("Yer imi kaldırıldı")
        else { list += Bookmark(t.web.title ?: url, url); toast("Yer imlerine eklendi ⭐") }
        store.bookmarks = list
    }

    private fun showBookmarks() {
        val (box, b) = sheet("Yer imleri")
        lateinit var dlg: AlertDialog
        val list = store.bookmarks
        if (list.isEmpty()) box.addView(label("Henüz yer imi yok. Menüden \"Yer imi ekle\" deyin.", 13f, DIM))
        list.forEach { bm ->
            box.addView(label("${bm.title}\n${bm.url}", 14f).apply {
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                setOnClickListener { current?.let { load(it, bm.url) }; dlg.dismiss() }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setMessage("\"${bm.title}\" silinsin mi?").setNegativeButton("Hayır", null)
                        .setPositiveButton("Sil") { _, _ -> store.bookmarks = store.bookmarks.filter { it.url != bm.url }; dlg.dismiss(); showBookmarks() }.show()
                    true
                }
            })
        }
        dlg = b.setPositiveButton("Kapat", null).setNeutralButton("Bu sayfayı ekle/kaldır") { _, _ -> toggleBookmark() }.create()
        dlg.show()
    }

    private fun showHistory() {
        val (box, b) = sheet("Geçmiş")
        lateinit var dlg: AlertDialog
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale("tr"))
        val list = store.history.take(200)
        if (list.isEmpty()) box.addView(label("Geçmiş boş", 13f, DIM))
        list.forEach { h ->
            box.addView(label("${h.title}\n${fmt.format(Date(h.t))} · ${Uri.parse(h.url).host}", 13f).apply {
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                setOnClickListener { current?.let { load(it, h.url) }; dlg.dismiss() }
            })
        }
        dlg = b.setPositiveButton("Kapat", null).setNegativeButton("Tümünü temizle") { _, _ -> store.history = emptyList(); toast("Geçmiş temizlendi") }.create()
        dlg.show()
    }

    private fun showSettings() {
        val (box, b) = sheet("Ayarlar")
        box.addView(label("GİZLİLİK & GÜVENLİK", 11f, DIM, true))
        switchRow(box, "Reklam & izleyici engelleyici", "100+ reklam/izleme ağı ve kripto madencisi", store.adblock) { store.adblock = it }
        switchRow(box, "Yalnızca HTTPS", "Şifresiz bağlantıları otomatik yükseltir", store.httpsOnly) { store.httpsOnly = it }
        switchRow(box, "Üçüncü taraf çerezlere izin ver", "Kapalı = siteler arası izleme engellenir", store.thirdPartyCookies) { v ->
            store.thirdPartyCookies = v; tabs.forEach { CookieManager.getInstance().setAcceptThirdPartyCookies(it.web, v) }
        }

        fun chooser(title: String, keys: List<String>, names: List<String>, cur: String, set: (String) -> Unit) {
            box.addView(label("$title: ${names[keys.indexOf(cur).coerceAtLeast(0)]}  ›", 14f, ACCENT).apply {
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle(title)
                        .setSingleChoiceItems(names.toTypedArray(), keys.indexOf(cur)) { d, w -> set(keys[w]); d.dismiss(); toast("$title: ${names[w]}") }.show()
                }
            })
        }
        chooser("Ay Kalkanı seviyesi", listOf("strict", "balanced", "off"), listOf("Sıkı", "Dengeli", "Kapalı"), store.shield) { store.shield = it }
        box.addView(label("ARAMA & GÖRÜNÜM", 11f, DIM, true).apply { setPadding(0, dp(16), 0, 0) })
        chooser("Arama motoru", listOf("duckduckgo", "brave", "startpage", "google", "bing", "yandex"),
            listOf("DuckDuckGo", "Brave", "Startpage", "Google", "Bing", "Yandex"), store.engine) { store.engine = it }
        chooser("Arka plan", listOf("auto", "nebula", "aurora", "moonrise", "eclipse", "galaxy"),
            listOf("Otomatik değişen", "Bulutsu", "Kutup ışığı", "Ay doğuşu", "Tutulma", "Galaksi"), store.background) { store.background = it }

        box.addView(label("VERİLER", 11f, DIM, true).apply { setPadding(0, dp(16), 0, 0) })
        box.addView(label("🧹 Önbellek, çerez ve geçmişi sil", 14f, DANGER).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("Tüm tarama verileri silinsin mi?").setNegativeButton("İptal", null)
                    .setPositiveButton("Sil") { _, _ ->
                        tabs.forEach { it.web.clearCache(true); it.web.clearFormData() }
                        CookieManager.getInstance().removeAllCookies(null)
                        WebStorage.getInstance().deleteAllData()
                        store.history = emptyList()
                        toast("Veriler temizlendi")
                    }.show()
            }
        })
        b.setPositiveButton("Tamam") { _, _ -> current?.let { if (it.web.url?.startsWith(ASSETS + "newtab") == true) load(it, "moon://newtab") } }.show()
    }

    // ═══════════════════════════ Görev penceresi ═══════════════════════════
    private val ACCENTS = listOf("#A99CFF", "#FFD98A", "#6EE7B7", "#7DD3FC", "#FB7185", "#F0ABFC")

    private fun showTasks() {
        val accent = store.taskAccent
        val (box, b) = sheet("☾ Görevler")
        lateinit var dlg: AlertDialog

        // özelleştirme: vurgu rengi
        val swRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        swRow.addView(label("Renk  ", 12f, DIM))
        ACCENTS.forEach { hex ->
            val c = Color.parseColor(hex)
            swRow.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); if (c == accent) setStroke(dp(2), Color.WHITE) }
                setOnClickListener { store.taskAccent = c; dlg.dismiss(); showTasks() }
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(8) })
        }
        box.addView(swRow)

        // ekleme formu
        val input = EditText(this).apply {
            hint = "Yeni görev…"; setTextColor(TEXT); setHintTextColor(DIM); setSingleLine()
            backgroundTintList = ColorStateList.valueOf(accent)
        }
        box.addView(input)
        var due: Long? = null
        var pri = "mid"
        var rep = "none"
        val opts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dueBtn = label("⏰ Zaman", 13f, accent).apply { setPadding(0, dp(6), dp(16), dp(6)) }
        val priBtn = label("● Orta", 13f, ACCENT).apply { setPadding(0, dp(6), dp(16), dp(6)) }
        val repBtn = label("↻ Tek sefer", 13f, DIM).apply { setPadding(0, dp(6), 0, dp(6)) }
        dueBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                TimePickerDialog(this, { _, h, min ->
                    cal.set(y, m, d, h, min, 0); due = cal.timeInMillis
                    dueBtn.text = "⏰ " + SimpleDateFormat("d MMM HH:mm", Locale("tr")).format(Date(due!!))
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        priBtn.setOnClickListener {
            pri = when (pri) { "mid" -> "high"; "high" -> "low"; else -> "mid" }
            priBtn.text = when (pri) { "high" -> "● Yüksek"; "low" -> "● Düşük"; else -> "● Orta" }
            priBtn.setTextColor(when (pri) { "high" -> DANGER; "low" -> SAFE; else -> ACCENT })
        }
        repBtn.setOnClickListener {
            rep = when (rep) { "none" -> "daily"; "daily" -> "weekly"; else -> "none" }
            repBtn.text = when (rep) { "daily" -> "↻ Her gün"; "weekly" -> "↻ Her hafta"; else -> "↻ Tek sefer" }
        }
        opts.addView(dueBtn); opts.addView(priBtn); opts.addView(repBtn)
        box.addView(opts)

        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        box.addView(listBox)

        fun render() {
            listBox.removeAllViews()
            val now = System.currentTimeMillis()
            val rank = mapOf("high" to 0, "mid" to 1, "low" to 2)
            val list = store.tasks.sortedWith(compareBy<Task>({ it.done }, { it.due ?: Long.MAX_VALUE }, { rank[it.priority] ?: 1 }))
            if (list.isEmpty()) listBox.addView(label("🌙 Burada görev yok", 13f, DIM))
            list.forEach { t ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(6), dp(8))
                    background = round(BG3, 12); alpha = if (t.done) .5f else 1f
                }
                val cb = CheckBox(this).apply {
                    isChecked = t.done; buttonTintList = ColorStateList.valueOf(accent)
                    setOnCheckedChangeListener { _, c ->
                        store.tasks = store.tasks.map { if (it.id == t.id) it.copy(done = c) else it }
                        store.tasks.find { it.id == t.id }?.let { ReminderReceiver.schedule(this@MainActivity, it) }
                        render()
                    }
                }
                val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                texts.addView(label(t.title, 14f).apply { setPadding(0, 0, 0, 0) })
                val meta = mutableListOf<String>()
                t.due?.let { meta += "⏰ " + SimpleDateFormat("d MMM HH:mm", Locale("tr")).format(Date(it)) }
                if (t.repeat == "daily") meta += "her gün"; if (t.repeat == "weekly") meta += "her hafta"
                if (t.cat.isNotBlank()) meta += "#${t.cat}"
                if (meta.isNotEmpty()) texts.addView(label(meta.joinToString(" · "), 12f,
                    if (!t.done && t.due != null && t.due!! < now) DANGER else DIM).apply { setPadding(0, dp(2), 0, 0) })
                val bar = View(this).apply { setBackgroundColor(when (t.priority) { "high" -> DANGER; "low" -> SAFE; else -> accent }) }
                val del = TextView(this).apply {
                    text = "✕"; setTextColor(DIM); textSize = 15f; setPadding(dp(12), dp(4), dp(8), dp(4))
                    setOnClickListener { ReminderReceiver.cancel(this@MainActivity, t); store.tasks = store.tasks.filter { it.id != t.id }; render() }
                }
                row.addView(bar, LinearLayout.LayoutParams(dp(3), dp(30)).apply { marginEnd = dp(6) })
                row.addView(cb); row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(del)
                listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
            }
        }
        render()

        dlg = b.setPositiveButton("Ekle", null).setNegativeButton("Kapat", null).create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(accent)
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = input.text.toString().trim()
                if (title.isEmpty()) { input.error = "Görev yazın"; return@setOnClickListener }
                val cat = Regex("#(\\S+)").find(title)?.groupValues?.get(1) ?: ""
                val task = Task(UUID.randomUUID().toString().take(12), title.replace(Regex("\\s*#\\S+"), "").ifBlank { title },
                    due, pri, cat, rep, done = false, notified = false)
                store.tasks = listOf(task) + store.tasks
                ReminderReceiver.schedule(this, task)
                input.setText(""); due = null; dueBtn.text = "⏰ Zaman"
                render()
                if (task.due != null) toast("Hatırlatıcı kuruldu — uygulama kapalıyken de bildirim gelir")
            }
        }
        dlg.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
        dlg.show()
    }
}
