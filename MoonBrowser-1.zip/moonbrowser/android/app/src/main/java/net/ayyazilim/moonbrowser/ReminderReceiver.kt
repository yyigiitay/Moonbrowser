package net.ayyazilim.moonbrowser

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Görev hatırlatıcıları — uygulama kapalıyken bile AlarmManager ile çalışır. */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) { scheduleAll(ctx); return }
        val id = intent.getStringExtra("id") ?: return
        val store = Store(ctx)
        val list = store.tasks.toMutableList()
        val t = list.find { it.id == id } ?: return
        if (t.done) return
        notify(ctx, t)
        when (t.repeat) {
            "daily" -> t.due = (t.due ?: System.currentTimeMillis()) + 86_400_000L
            "weekly" -> t.due = (t.due ?: System.currentTimeMillis()) + 7 * 86_400_000L
            else -> t.notified = true
        }
        store.tasks = list
        if (!t.notified) schedule(ctx, t)
    }

    companion object {
        private const val CHANNEL = "moon_tasks"

        fun ensureChannel(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Görev hatırlatıcıları", NotificationManager.IMPORTANCE_HIGH))
            }
        }

        private fun notify(ctx: Context, t: Task) {
            ensureChannel(ctx)
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).putExtra("openTasks", true),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("🌙 Görev zamanı")
                .setContentText(t.title)
                .setStyle(NotificationCompat.BigTextStyle().bigText(t.title + if (t.cat.isNotBlank()) "  #${t.cat}" else ""))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            NotificationManagerCompat.from(ctx).notify(t.id.hashCode(), n)
        }

        private fun pending(ctx: Context, t: Task): PendingIntent = PendingIntent.getBroadcast(
            ctx, t.id.hashCode(), Intent(ctx, ReminderReceiver::class.java).putExtra("id", t.id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun schedule(ctx: Context, t: Task) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val due = t.due
            if (t.done || t.notified || due == null) { am.cancel(pending(ctx, t)); return }
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, maxOf(due, System.currentTimeMillis() + 1000), pending(ctx, t))
        }

        fun cancel(ctx: Context, t: Task) = ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, t))

        fun scheduleAll(ctx: Context) = Store(ctx).tasks.forEach { schedule(ctx, it) }
    }
}
