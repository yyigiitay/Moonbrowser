'use strict';
const P = new URLSearchParams(location.search);
const mode = P.get('mode') || 'threat';
const url = P.get('url') || '';
const $ = id => document.getElementById(id);
const safeUrl = /^https?:\/\//i.test(url) ? url : '';
$('url').textContent = url || '(adres yok)';

const goHome = () => { if (history.length > 1) history.back(); else location.href = 'newtab.html'; };

if (mode === 'threat') {
  const score = Number(P.get('score')) || 0;
  let reasons = [];
  try { reasons = JSON.parse(P.get('reasons') || '[]'); } catch { reasons = []; }
  $('badge').textContent = '🛡️';
  $('title').textContent = 'Ay Kalkanı bu sayfayı durdurdu';
  $('lead').textContent = 'Bu adres dolandırıcılık (oltalama) veya zararlı yazılım sitelerinde görülen işaretler taşıyor. Şifre, kart bilgisi veya kişisel bilgi girmeyin.';
  $('meter').hidden = false;
  $('meter').firstElementChild.style.width = Math.min(100, score) + '%';
  for (const r of reasons) { const li = document.createElement('li'); li.textContent = r; $('reasons').append(li); }
  const li = document.createElement('li'); li.textContent = `Toplam risk puanı: ${score}/100`; $('reasons').append(li);
  $('primary').textContent = 'Güvenli yere dön';
  $('primary').onclick = goHome;
  if (safeUrl) {
    $('more').hidden = false;
    $('more-text').textContent = 'Bu sitenin güvenli olduğundan eminseniz devam edebilirsiniz. Kalkan bu siteyi bu sekmede bir daha durdurmaz.';
    $('risky').textContent = 'Riskleri anlıyorum, yine de aç';
    $('risky').onclick = () => { location.href = safeUrl; };
  }
} else {
  document.body.classList.add('error');
  const crash = mode === 'crash';
  $('badge').textContent = crash ? '💥' : '🌑';
  $('title').textContent = crash ? 'Bu sekme çöktü' : 'Sayfaya ulaşılamadı';
  const desc = P.get('desc') || '';
  const hints = {
    ERR_NAME_NOT_RESOLVED: 'Alan adı bulunamadı. Adresi kontrol edin.',
    ERR_INTERNET_DISCONNECTED: 'İnternet bağlantınız yok gibi görünüyor.',
    ERR_CONNECTION_REFUSED: 'Sunucu bağlantıyı reddetti.',
    ERR_CONNECTION_TIMED_OUT: 'Sunucu zamanında yanıt vermedi.',
    ERR_CERT_AUTHORITY_INVALID: 'Sitenin güvenlik sertifikası geçersiz — saldırgan araya girmiş olabilir. Devam edilmesine izin verilmez.',
    ERR_CERT_DATE_INVALID: 'Sitenin güvenlik sertifikasının süresi dolmuş.',
    ERR_CERT_COMMON_NAME_INVALID: 'Sertifika bu siteye ait değil — sahte site olabilir.',
    ERR_SSL_PROTOCOL_ERROR: 'Güvenli bağlantı kurulamadı.'
  };
  $('lead').textContent = crash ? `Sayfa işlemi beklenmedik şekilde sonlandı (${desc}). Diğer sekmeleriniz etkilenmedi.`
    : (hints[desc] || 'Bağlantı kurulamadı.') + (desc ? ` (${desc})` : '');
  $('primary').textContent = 'Tekrar dene';
  $('primary').onclick = () => { if (safeUrl) location.href = safeUrl; else goHome(); };
  const certErr = desc.startsWith('ERR_CERT');
  if (P.get('https') === '1' && safeUrl.startsWith('https:') && !certErr && !crash) {
    $('secondary').hidden = false;
    $('secondary').textContent = 'Şifresiz (HTTP) dene — güvensiz';
    $('secondary').onclick = () => { location.href = safeUrl.replace(/^https:/i, 'http:'); };
  }
}
