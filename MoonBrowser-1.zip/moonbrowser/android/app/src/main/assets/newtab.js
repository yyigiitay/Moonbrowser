'use strict';
const P = new URLSearchParams(location.search);
const ENGINES = {
  duckduckgo: ['DuckDuckGo', 'https://duckduckgo.com/?q='], google: ['Google', 'https://www.google.com/search?q='],
  brave: ['Brave', 'https://search.brave.com/search?q='], startpage: ['Startpage', 'https://www.startpage.com/do/search?q='],
  yandex: ['Yandex', 'https://yandex.com.tr/search/?text='], bing: ['Bing', 'https://www.bing.com/search?q=']
};
const SCENE_NAMES = { nebula: 'Bulutsu', aurora: 'Kutup ışığı', moonrise: 'Ay doğuşu', eclipse: 'Tutulma', galaxy: 'Galaksi', custom: 'Senin resmin' };
const isPriv = P.get('priv') === '1';
const engine = ENGINES[P.get('engine')] || ENGINES.duckduckgo;
let bm = [];
try { bm = JSON.parse(P.get('bm') || '[]'); } catch { bm = []; }

document.body.classList.toggle('priv', isPriv);
document.getElementById('priv-note').hidden = !isPriv;
document.getElementById('engine').textContent = engine[0];

// ── Arama ──
const q = document.getElementById('q');
document.getElementById('search').addEventListener('submit', e => {
  e.preventDefault();
  const v = q.value.trim();
  if (!v) return;
  const looksUrl = !/\s/.test(v) && /^(https?:\/\/)?[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(v);
  location.href = looksUrl ? (/^https?:\/\//.test(v) ? v : 'https://' + v) : engine[1] + encodeURIComponent(v);
});
setTimeout(() => q.focus(), 50);

// ── Kısayollar ──
const tiles = document.getElementById('tiles');
for (const b of bm.slice(0, 8)) {
  if (!/^https?:\/\//.test(b.u)) continue;
  const a = document.createElement('a');
  a.className = 'tile'; a.href = b.u; a.title = b.u;
  const l = document.createElement('span'); l.className = 'l';
  l.textContent = (String(b.t || b.u).replace(/^(https?:\/\/)?(www\.)?/, '')[0] || '?').toUpperCase();
  const t = document.createElement('span'); t.textContent = b.t || b.u;
  a.append(l, t); tiles.append(a);
}

// ── Saat & selam ──
function tick() {
  const d = new Date();
  document.getElementById('clock').textContent = d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  const h = d.getHours();
  const g = h < 5 ? 'İyi geceler, ay seninle 🌙' : h < 12 ? 'Günaydın ☀️' : h < 17 ? 'İyi günler' : h < 22 ? 'İyi akşamlar 🌆' : 'İyi geceler 🌙';
  document.getElementById('greet').textContent = g + ' · ' + d.toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
}
tick(); setInterval(tick, 1000);

// ── Gerçek ay evresi ──
(function phase() {
  const syn = 29.530588853;
  const ref = Date.UTC(2000, 0, 6, 18, 14) / 86400000;
  const age = (((Date.now() / 86400000 - ref) % syn) + syn) % syn;
  const f = age / syn; // 0 yeni ay, .5 dolunay
  const names = ['Yeni ay', 'Hilal', 'İlk dördün', 'Şişkin ay', 'Dolunay', 'Şişkin ay', 'Son dördün', 'Hilal'];
  document.getElementById('phase-name').textContent = names[Math.round(f * 8) % 8] + ` · %${Math.round((1 - Math.cos(2 * Math.PI * f)) / 2 * 100)} aydınlık`;
  const shade = document.querySelector('.shade');
  const lit = (1 - Math.cos(2 * Math.PI * f)) / 2;
  const w = 26 * (1 - lit);
  shade.style.width = Math.max(0, w * 2) + 'px';
  shade.style.left = f < 0.5 ? (-w) + 'px' : (26 - w) + 'px';
})();

// ── Değişen arka planlar ──
const all = [...document.querySelectorAll('.scene')];
const custom = P.get('custom');
if (custom) all.find(s => s.dataset.s === 'custom').style.backgroundImage = `url("${custom.replace(/"/g, '%22')}")`;
const mode = P.get('bg') || 'auto';
const pool = mode === 'auto' ? all.filter(s => s.dataset.s !== 'custom' || custom).map(s => s.dataset.s) : [mode === 'custom' && !custom ? 'nebula' : mode];
let idx = Math.floor(Math.random() * pool.length);
function show(name) {
  all.forEach(s => s.classList.toggle('on', s.dataset.s === name));
  document.getElementById('scene-name').textContent = SCENE_NAMES[name] || '';
}
show(pool[idx]);
if (pool.length > 1) {
  const sec = Math.max(5, Number(P.get('interval')) || 25);
  setInterval(() => { idx = (idx + 1) % pool.length; show(pool[idx]); }, sec * 1000);
}

// ── Yıldızlar + kayan yıldızlar ──
const cv = document.getElementById('sky');
const cx = cv.getContext('2d');
let stars = [], shooting = null, W = 0, H = 0;
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
function resize() {
  const dpr = Math.min(2, devicePixelRatio || 1);
  W = innerWidth; H = innerHeight;
  cv.width = W * dpr; cv.height = H * dpr; cx.setTransform(dpr, 0, 0, dpr, 0, 0);
  stars = Array.from({ length: Math.round(W * H / 5200) }, () => ({
    x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.2 + 0.2, p: Math.random() * 6.28, s: 0.4 + Math.random() * 1.6
  }));
}
addEventListener('resize', resize); resize();
function frame(t) {
  cx.clearRect(0, 0, W, H);
  for (const st of stars) {
    const a = 0.35 + 0.65 * Math.abs(Math.sin(st.p + t / 1000 * st.s * 0.6));
    cx.globalAlpha = a; cx.fillStyle = '#fff';
    cx.beginPath(); cx.arc(st.x, st.y, st.r, 0, 6.283); cx.fill();
  }
  if (!shooting && Math.random() < 0.004) shooting = { x: Math.random() * W * 0.7, y: Math.random() * H * 0.4, l: 0 };
  if (shooting) {
    shooting.l += 14;
    const len = 120, x2 = shooting.x + shooting.l, y2 = shooting.y + shooting.l * 0.45;
    const g = cx.createLinearGradient(x2 - len, y2 - len * 0.45, x2, y2);
    g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(255,240,210,.9)');
    cx.globalAlpha = 1; cx.strokeStyle = g; cx.lineWidth = 1.6;
    cx.beginPath(); cx.moveTo(x2 - len, y2 - len * 0.45); cx.lineTo(x2, y2); cx.stroke();
    if (shooting.l > W * 0.5) shooting = null;
  }
  if (!reduce) requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
